# BuildMind Member 6 — Step 8 Automatic Draft Floor Planner

## Run on Windows
1. Extract the ZIP fully.
2. Double-click `START_AUTO_PLANNER.bat` (Python `py` launcher required).
3. Visit `http://localhost:8765` if the browser does not open automatically.
4. Enter site width/depth, bedroom count, and illustrative footprint percentage.
5. Click **Generate draft layout**, use the 2D tab, move objects or open 3D scene.
6. Export JSON; import it again with the file chooser.

## Capabilities
- One ZIP contains all 1,200 conceptual objects and 2D/3D files from Step 7.
- Draft layout of living room, kitchen, 1–4 bedrooms and one bathroom using deterministic two-column grid.
- Automatically selects representative objects when they fit.
- Room-zone display in 2D, outer building footprint in 3D, GLB assets in viewer.
- Manual drag/rotate, basic collision and room-boundary warnings, JSON export/import.

## Limitations
- No language model is involved; the generator is deterministic and preliminary.
- Room zones are illustrative: no interior walls in 3D, circulation corridors, structural design, openings, structural loads, setbacks, utility routing, daylight/ventilation or regulations validation.
- Percentage is a *requested* concept footprint. Do not treat it as Sri Lankan permissible site coverage or plot ratio.
- All 1,200 3D assets remain conceptual and unverified; source licensing and real dimensions require validation.
- Three.js loads via external CDN when 3D mode is opened (requires internet).
- This is not an engineering/architectural approval drawing or construction-ready plan.

## Important files
- `index.html` — local 2D and 3D app
- `catalog.json` — 1,200 object metadata
- `assets/` — 1,200 SVG plans, 1,200 elevations, 1,200 PNG previews, 1,200 GLB models, 1,200 JSON metadata

## Asset repair
219 2D SVG footprints were missing from inherited Step 7 package. Replaced with *explicitly labelled simplified footprint* diagrams, not original CAD views.
