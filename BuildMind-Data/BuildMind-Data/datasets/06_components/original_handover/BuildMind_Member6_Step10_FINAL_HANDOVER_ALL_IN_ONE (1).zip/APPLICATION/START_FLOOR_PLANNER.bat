@echo off
cd /d "%~dp0"
echo Open http://localhost:8765 in your browser
py -m http.server 8765
pause
