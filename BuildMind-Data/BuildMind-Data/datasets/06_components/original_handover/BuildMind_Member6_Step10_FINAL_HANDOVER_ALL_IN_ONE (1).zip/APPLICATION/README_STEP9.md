# BuildMind Step 9 — Sri Lanka Site Intelligence Integration Prototype

## Run
Extract ZIP. Double-click `START_AUTO_PLANNER.bat`; open http://localhost:8765. Python `py` launcher required on Windows.

## What was added
A Site Intelligence panel for district and *user-entered* rainfall, wind, soil-report flag, budget, cost rate, permitted coverage, front and side setbacks. Analyze a generated draft; export site assessment JSON. The existing 1,200 conceptual objects and 2D/3D planner remain included. Existing floor-plan JSON export now includes the latest site assessment.

## Important limitations
- NO live weather API; no verified district values bundled.
- NO linked Sri Lanka UDA or municipal rules. A limit entered by the user is *not* automatically a valid local rule.
- NO linked actual construction quotations or BOQ; price is user-entered LKR/m² and excludes a full take-off, contingencies, taxes etc.
- Setback checks assume centered rectangular plan, front orientation along site depth, and do not check rear setbacks.
- Weather values are context only, not wind/flood engineering calculations.
- Concept 2D/3D models are not manufacturer verified, architectural approval ready, or structurally certified.
- No LLM/AI model is connected. All logic is deterministic.
- Internet required for the Three.js CDN in 3D mode.

## Integrating Members 1–5 & 7 in future
Use `INTEGRATION_CONTRACT.json` as a draft interface contract. Validate authoritative data, jurisdictions, licenses, provenance and update dates before API ingestion. Keep calculations in tested deterministic services and put human review in approval workflow.

## Data privacy
The prototype runs locally via HTTP. It does not upload data to a server. Exported JSON stays on the user's computer.
