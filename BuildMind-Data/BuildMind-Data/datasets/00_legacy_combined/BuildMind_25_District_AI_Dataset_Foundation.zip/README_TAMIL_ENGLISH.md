# BuildMind – 25 District Official-Source Dataset Foundation

**STATUS: RESEARCH FOUNDATION, NOT A COMPLETE VERIFIED LEGAL RULE DATABASE.**

Tamil: 25 மாவட்டங்களுக்கான index தயாரிக்கப்பட்டுள்ளது. ஆனால் அனைத்து local authority மற்றும் zoning numerical regulations இன்னும் verify செய்யப்படவில்லை. இந்த dataset மட்டும் வைத்து building permit approval அல்லது legal compliance என்று AI சொல்லக்கூடாது.

## Files
- district_index.csv: 25 districts and examples of official UDA plan listings; not exhaustive.
- official_sources.csv: Official authority references.
- rule_collection_queue.csv: 24 rule categories requiring clause-by-clause extraction. Blank numerical values intentionally mean unverified.
- location_authority_mapping.csv: Local authority and zone lookup work queue.
- rule_master_schema.csv: Normalized verified rules import format.
- ai_validation_example.json: Fail-closed validation response.

## Implementation
1. Resolve parcel coordinates, district, local authority, UDA declaration and gazetted zone.
2. Fetch applicable, effective Gazette and local plan, plus sector-specific restrictions.
3. Extract exact rule clause, numeric value, units, conditions, exceptions, date and page.
4. Have qualified reviewer verify interpretation; never invent absent numeric values.
5. Use deterministic geometry/rule checker; AI generates suggestions and explains references, not legal approval.
6. Mark missing zoning or conflicting clauses as NEEDS_MANUAL_REVIEW.

## Official references
UDA Gazette: https://www.uda.gov.lk/attachments/act/2235-54_E.pdf
UDA plans: https://www.uda.gov.lk/applicable_dev_plans.html
My Zone: https://www.uda.gov.lk/myzoneuda.html
Coastal permits: https://coastal.gov.lk/index.php/en/downloads/permit-information

**Legal caution:** Official publication availability is not proof of current applicability to a specific parcel. Check subsequent amendments and competent authority.
