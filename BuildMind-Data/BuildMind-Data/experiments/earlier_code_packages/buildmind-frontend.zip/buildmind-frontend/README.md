# BuildMind Frontend

Simple frontend to test the BuildMind n8n + Cloudflare Workers AI render workflow.

## Expected n8n production webhook

http://localhost:5678/webhook/buildmind-render

## Start

Option 1:
Open `index.html` directly in the browser.

Option 2 (recommended):
From this folder run:

python -m http.server 5500

Then open:

http://localhost:5500

## Important: CORS

If the browser shows `Failed to fetch` while PowerShell works, the n8n webhook may need CORS enabled.

For local development, start n8n with an allowed origin / CORS configuration appropriate for your setup, or serve the frontend from a backend/proxy that calls n8n server-side.

## n8n response expected

{
  "success": true,
  "message": "BuildMind AI render generated successfully",
  "imageBase64": "...",
  "imageDataUrl": "data:image/jpeg;base64,...",
  "provider": "Cloudflare Workers AI",
  "model": "@cf/black-forest-labs/flux-1-schnell"
}

## Files

- index.html
- styles.css
- app.js
- README.md
