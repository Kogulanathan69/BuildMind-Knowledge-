const roomList = document.getElementById('roomList');
const roomTemplate = document.getElementById('roomTemplate');
const generateBtn = document.getElementById('generateBtn');
const addRoomBtn = document.getElementById('addRoomBtn');
const renderImage = document.getElementById('renderImage');
const renderArea = document.getElementById('renderArea');
const responseLog = document.getElementById('responseLog');
const statusBadge = document.getElementById('statusBadge');
const downloadBtn = document.getElementById('downloadBtn');
const clearLogBtn = document.getElementById('clearLogBtn');
const summary = document.getElementById('summary');

let latestImageDataUrl = '';

function addRoom(room = {}) {
  const node = roomTemplate.content.cloneNode(true);
  const card = node.querySelector('.room-card');

  card.querySelector('.room-name').value = room.name ?? 'Room';
  card.querySelector('.room-x').value = room.x ?? 0;
  card.querySelector('.room-y').value = room.y ?? 0;
  card.querySelector('.room-width').value = room.width ?? 12;
  card.querySelector('.room-height').value = room.height ?? 10;

  card.querySelector('.remove-room').addEventListener('click', () => {
    card.remove();
    updateSummary();
  });

  card.querySelectorAll('input').forEach(input => {
    input.addEventListener('input', updateSummary);
  });

  roomList.appendChild(node);
  updateSummary();
}

function getRooms() {
  return [...document.querySelectorAll('.room-card')].map(card => ({
    name: card.querySelector('.room-name').value.trim() || 'Room',
    x: Number(card.querySelector('.room-x').value || 0),
    y: Number(card.querySelector('.room-y').value || 0),
    width: Number(card.querySelector('.room-width').value || 0),
    height: Number(card.querySelector('.room-height').value || 0),
  }));
}

function getPayload() {
  return {
    selectedDesign: {
      name: document.getElementById('designName').value.trim() || 'Design A',
      strategy: document.getElementById('strategy').value.trim() || 'Residential layout',
      score: 100
    },
    land: {
      width: Number(document.getElementById('landWidth').value || 40),
      length: Number(document.getElementById('landLength').value || 60),
      unit: 'ft'
    },
    rooms: getRooms(),
    doors: [],
    windows: [],
    renderType: document.getElementById('renderType').value,
    style: document.getElementById('style').value,
    theme: document.getElementById('theme').value,
    furnished: document.getElementById('furnished').checked
  };
}

function updateSummary() {
  const payload = getPayload();
  summary.innerHTML = `
    <div class="summary-item">
      <strong>Design</strong>
      ${escapeHtml(payload.selectedDesign.name)}
    </div>
    <div class="summary-item">
      <strong>Land</strong>
      ${payload.land.width} × ${payload.land.length} ${payload.land.unit}
    </div>
    <div class="summary-item">
      <strong>Rooms</strong>
      ${payload.rooms.length}
    </div>
    <div class="summary-item">
      <strong>Room Names</strong>
      ${payload.rooms.map(r => escapeHtml(r.name)).join(', ') || 'None'}
    </div>
    <div class="summary-item">
      <strong>Render</strong>
      ${escapeHtml(payload.renderType)} · ${escapeHtml(payload.style)} · ${escapeHtml(payload.theme)}
    </div>
  `;
}

function setStatus(type, text) {
  statusBadge.className = `status ${type}`;
  statusBadge.textContent = text;
}

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

async function generateRender() {
  const webhookUrl = document.getElementById('webhookUrl').value.trim();

  if (!webhookUrl) {
    alert('Please enter the n8n webhook URL.');
    return;
  }

  const payload = getPayload();

  generateBtn.disabled = true;
  generateBtn.textContent = 'Generating...';
  setStatus('loading', 'Generating');
  responseLog.textContent = 'Sending request to n8n...';

  try {
    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });

    const rawText = await response.text();

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${rawText}`);
    }

    let data;
    try {
      data = JSON.parse(rawText);
    } catch {
      throw new Error('n8n returned a non-JSON response.');
    }

    responseLog.textContent = JSON.stringify({
      success: data.success,
      message: data.message,
      provider: data.provider,
      model: data.model,
      imageBase64Length: data.imageBase64?.length ?? 0
    }, null, 2);

    if (!data.success) {
      throw new Error(data.message || 'Image generation failed.');
    }

    if (data.imageDataUrl) {
      latestImageDataUrl = data.imageDataUrl;
    } else if (data.imageBase64) {
      latestImageDataUrl = `data:image/jpeg;base64,${data.imageBase64}`;
    } else {
      throw new Error('No imageBase64/imageDataUrl found in n8n response.');
    }

    renderImage.src = latestImageDataUrl;
    renderImage.style.display = 'block';

    const placeholder = renderArea.querySelector('.placeholder');
    if (placeholder) {
      placeholder.style.display = 'none';
    }

    downloadBtn.disabled = false;
    setStatus('success', 'Completed');
  } catch (error) {
    console.error(error);
    setStatus('error', 'Failed');
    responseLog.textContent = String(error.message || error);

    if (String(error.message || error).toLowerCase().includes('failed to fetch')) {
      responseLog.textContent += `

Possible reasons:
1. n8n is not running.
2. Wrong webhook URL.
3. Browser CORS blocked the request.
4. Workflow is not published.
5. The webhook is using /webhook-test/ without Listen for test event.`;
    }
  } finally {
    generateBtn.disabled = false;
    generateBtn.textContent = 'Generate AI Render';
  }
}

function downloadImage() {
  if (!latestImageDataUrl) return;

  const link = document.createElement('a');
  link.href = latestImageDataUrl;
  link.download = `buildmind-render-${Date.now()}.jpg`;
  document.body.appendChild(link);
  link.click();
  link.remove();
}

addRoomBtn.addEventListener('click', () => addRoom());
generateBtn.addEventListener('click', generateRender);
downloadBtn.addEventListener('click', downloadImage);
clearLogBtn.addEventListener('click', () => {
  responseLog.textContent = 'Waiting for request...';
});

[
  'designName',
  'strategy',
  'landWidth',
  'landLength',
  'style',
  'theme',
  'renderType',
  'furnished'
].forEach(id => {
  document.getElementById(id).addEventListener('input', updateSummary);
  document.getElementById(id).addEventListener('change', updateSummary);
});

// Initial sample rooms matching the current n8n test.
addRoom({
  name: 'Living Room',
  x: 0,
  y: 0,
  width: 30,
  height: 14
});

addRoom({
  name: 'Kitchen',
  x: 0,
  y: 14,
  width: 14,
  height: 11
});

updateSummary();
