import { ChangeDetectorRef, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Component({
  selector:'app-root', standalone:true,
  imports:[CommonModule,FormsModule],
  templateUrl:'./app.html', styleUrl:'./app.css'
})
export class App {
  userMessage=''; loading=false; generated=false; errorMessage='';
  selectedDesign:any=null; designOptions:any[]=[]; validation:any=null;
  rooms:any[]=[]; doors:any[]=[]; windows:any[]=[]; land:any=null;
  safeSvg:SafeHtml|null=null; activeOptionName='';

  readonly samplePrompt='I have a 40 x 60 ft land. I need 3 bedrooms, 2 bathrooms, 1 car parking, a large kitchen and good ventilation.';

  constructor(private http:HttpClient, private sanitizer:DomSanitizer, private cdr:ChangeDetectorRef){}

  useSample(){ this.userMessage=this.samplePrompt; }

  generatePlan(){
    if(!this.userMessage.trim()){this.errorMessage='Please enter your house requirements.';return;}
    this.loading=true; this.generated=false; this.errorMessage=''; this.safeSvg=null;
    const body={message:this.userMessage.trim()};
    this.http.post<any>('/api/webhook/buildmind-generate',body).subscribe({
      next:(response)=>{
        const data=Array.isArray(response)?response[0]:response;
        this.land=data?.land??{width:40,length:60,unit:'ft'};
        this.selectedDesign=data?.selectedDesign??null;
        this.designOptions=data?.designOptions??[];
        this.validation=data?.validation??null;
        this.rooms=data?.rooms??[]; this.doors=data?.doors??[]; this.windows=data?.windows??[];
        this.activeOptionName=this.selectedDesign?.name??'';
        const svg=(typeof data?.svgPreview==='string'&&data.svgPreview.includes('<svg'))
          ? data.svgPreview
          : this.buildSvg(this.rooms,this.doors,this.windows,this.selectedDesign?.name??'Selected Design',this.selectedDesign?.score??null);
        this.safeSvg=this.sanitizer.bypassSecurityTrustHtml(svg);
        this.loading=false; this.generated=true; this.cdr.detectChanges();
      },
      error:(err)=>{
        console.error('BuildMind error:',err);
        this.loading=false; this.generated=false;
        this.errorMessage='Unable to generate the plan. Make sure n8n is running and the workflow is published.';
        this.cdr.detectChanges();
      }
    });
  }

  selectDesign(option:any){
    this.activeOptionName=option.name;
    this.selectedDesign={name:option.name,strategy:option.strategy??'',score:option.score??0,explanations:option.explanations??[]};
    this.rooms=option.rooms??[]; this.doors=option.doors??[]; this.windows=option.windows??[];
    this.validation=option.validation??this.validation;
    this.safeSvg=this.sanitizer.bypassSecurityTrustHtml(
      this.buildSvg(this.rooms,this.doors,this.windows,option.name,option.score??null)
    );
    window.scrollTo({top:0,behavior:'smooth'});
    this.cdr.detectChanges();
  }

  resetDesign(){
    this.userMessage=''; this.loading=false; this.generated=false; this.errorMessage='';
    this.safeSvg=null; this.selectedDesign=null; this.designOptions=[]; this.validation=null;
    this.rooms=[]; this.doors=[]; this.windows=[]; this.land=null; this.activeOptionName='';
  }

  private buildSvg(rooms:any[],doors:any[],windows:any[],name:string,score:number|null){
    const lw=Number(this.land?.width??40), ll=Number(this.land?.length??60), unit=String(this.land?.unit??'ft');
    const W=900,H=760,L=70,T=100,R=150,B=70;
    const s=Math.min((W-L-R)/lw,(H-T-B)/ll), pxX=(x:number)=>L+x*s, pxY=(y:number)=>T+y*s;
    const esc=(v:any)=>String(v??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    const color=(r:any)=>{const n=String(r.name||'').toLowerCase();
      if(n.includes('backyard')||n.includes('utility'))return'#edf8e8';
      if(n.includes('living'))return'#fff5dc'; if(n.includes('kitchen'))return'#ffeede';
      if(n.includes('dining'))return'#fff8dc'; if(n.includes('master'))return'#e8efff';
      if(n.includes('bedroom'))return'#f0f4ff'; if(n.includes('bath'))return'#e4f6ff';
      if(n.includes('parking'))return'#eee'; if(n.includes('corridor'))return'#f8f8f8'; return'#f7f7f7';};
    let svg=`<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
    <rect width="100%" height="100%" fill="white"/>
    <text x="${W/2}" y="32" text-anchor="middle" font-size="24" font-family="Arial" font-weight="bold">BuildMind - AI Generated 2D Floor Plan</text>
    <text x="${W/2}" y="55" text-anchor="middle" font-size="12" font-family="Arial" fill="#667085">Interactive Design Preview</text>
    <text x="${L}" y="80" font-size="14" font-family="Arial" font-weight="bold" fill="#3157ff">${esc(name)}</text>
    ${score!==null?`<text x="${L+180}" y="80" font-size="13" font-family="Arial" font-weight="bold" fill="#059669">AI Score: ${score}</text>`:''}
    <text x="${L+(lw*s)/2}" y="${T-18}" text-anchor="middle" font-size="13" font-family="Arial" font-weight="bold">FRONT / ROAD</text>
    <rect x="${L}" y="${T}" width="${lw*s}" height="${ll*s}" fill="white" stroke="#111" stroke-width="5"/>`;
    for(const r of rooms){const x=pxX(r.x),y=pxY(r.y),w=r.width*s,h=r.height*s,fs=r.width*r.height<45?9:11;
      svg+=`<g><rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${color(r)}" stroke="#1f2937" stroke-width="2"/>
      <text x="${x+w/2}" y="${y+h/2-5}" text-anchor="middle" font-family="Arial" font-size="${fs}" font-weight="bold">${esc(r.name)}</text>
      <text x="${x+w/2}" y="${y+h/2+12}" text-anchor="middle" font-family="Arial" font-size="${Math.max(fs-1,8)}">${r.width} × ${r.height} ${esc(unit)}</text></g>`;}
    for(const d of doors){const x=pxX(d.x),y=pxY(d.y),z=(d.width??3)*s;
      if(d.orientation==='vertical')svg+=`<line x1="${x}" y1="${y}" x2="${x}" y2="${y+z}" stroke="white" stroke-width="7"/><line x1="${x}" y1="${y}" x2="${x+z}" y2="${y}" stroke="#92400e" stroke-width="2"/><path d="M ${x} ${y+z} A ${z} ${z} 0 0 1 ${x+z} ${y}" fill="none" stroke="#92400e" stroke-width="1.3" stroke-dasharray="3 2"/>`;
      else svg+=`<line x1="${x}" y1="${y}" x2="${x+z}" y2="${y}" stroke="white" stroke-width="7"/><line x1="${x}" y1="${y}" x2="${x}" y2="${y+z}" stroke="#92400e" stroke-width="2"/><path d="M ${x+z} ${y} A ${z} ${z} 0 0 1 ${x} ${y+z}" fill="none" stroke="#92400e" stroke-width="1.3" stroke-dasharray="3 2"/>`;}
    for(const w of windows){const x=pxX(w.x),y=pxY(w.y),z=(w.width??4)*s;
      if(w.orientation==='vertical')svg+=`<line x1="${x}" y1="${y}" x2="${x}" y2="${y+z}" stroke="white" stroke-width="8"/><line x1="${x-2}" y1="${y}" x2="${x-2}" y2="${y+z}" stroke="#2563eb" stroke-width="2"/><line x1="${x+2}" y1="${y}" x2="${x+2}" y2="${y+z}" stroke="#2563eb" stroke-width="2"/>`;
      else svg+=`<line x1="${x}" y1="${y}" x2="${x+z}" y2="${y}" stroke="white" stroke-width="8"/><line x1="${x}" y1="${y-2}" x2="${x+z}" y2="${y-2}" stroke="#2563eb" stroke-width="2"/><line x1="${x}" y1="${y+2}" x2="${x+z}" y2="${y+2}" stroke="#2563eb" stroke-width="2"/>`;}
    svg+=`<text x="${W/2}" y="${H-18}" text-anchor="middle" font-family="Arial" font-size="10" fill="#667085">BuildMind Concept Plan — Final construction drawings require professional review.</text></svg>`;
    return svg;
  }
}
