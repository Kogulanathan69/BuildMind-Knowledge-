# BuildMind Frontend - Selectable Designs

## Features
- Natural-language requirement input
- Production n8n webhook integration
- AI-generated 2D plan display
- Clickable Design A / B / C
- Preview updates when a design is selected
- Layout score, strategy, validation, AI reasons
- Ready for next 3D phase

## n8n
Publish the workflow and use:
- POST
- Path: `buildmind-generate`
- Respond: `When Last Node Finishes`

## Run
```powershell
npm.cmd install
npm.cmd start
```
Open http://localhost:4200

n8n should run on http://localhost:5678

The frontend calls `/api/webhook/buildmind-generate`.
