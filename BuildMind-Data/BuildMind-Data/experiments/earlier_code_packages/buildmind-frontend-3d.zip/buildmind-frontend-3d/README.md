# BuildMind Frontend + Three.js 3D

## Features
- AI requirement input
- n8n production webhook
- Design A/B/C selection
- 2D SVG preview
- Interactive Three.js 3D preview
- Rotate, zoom and pan
- Room floors, walls, doors and window markers

## Run
```powershell
npm.cmd install
npm.cmd start
```
Open http://localhost:4200

Make sure n8n is running on http://localhost:5678 and the workflow is published/active.

The 3D output is a prototype visualization, not construction-ready geometry.
