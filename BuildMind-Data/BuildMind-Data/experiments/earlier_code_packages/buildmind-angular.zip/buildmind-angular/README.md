# BuildMind Angular Frontend

This Angular frontend connects to the working n8n production webhook:

http://localhost:5678/webhook/buildmind-render

## Requirements

Use a Node.js version compatible with Angular 22.

## Run

Open PowerShell inside this folder:

npm install

ng serve --open

or:

npm start

Then Angular will normally open at:

http://localhost:4200

## Required n8n workflow

Webhook
→ Prepare AI Render
→ HTTP Request (Cloudflare Workers AI)
→ Format Image Response
→ Respond to Webhook

Expected response:

{
  "success": true,
  "message": "BuildMind AI render generated successfully",
  "imageBase64": "...",
  "imageDataUrl": "data:image/jpeg;base64,...",
  "provider": "Cloudflare Workers AI",
  "model": "@cf/black-forest-labs/flux-1-schnell"
}

## Browser CORS

If PowerShell succeeds but Angular shows a browser network/CORS error,
the browser is blocking the request to n8n. In that case configure n8n
to allow the Angular origin http://localhost:4200 or add a backend/proxy.
