import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

interface Room {
  name: string;
  x: number;
  y: number;
  width: number;
  height: number;
}

interface RenderResponse {
  success: boolean;
  message?: string;
  imageBase64?: string;
  imageDataUrl?: string;
  provider?: string;
  model?: string;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  webhookUrl = 'http://localhost:5678/webhook/buildmind-render';

  designName = 'Design A';
  strategy = 'Front Public - Rear Private';
  landWidth = 40;
  landLength = 60;
  style = 'modern premium';
  theme = 'day';
  renderType = 'openRoof';
  furnished = true;

  rooms: Room[] = [
    { name: 'Living Room', x: 0, y: 0, width: 30, height: 14 },
    { name: 'Kitchen', x: 0, y: 14, width: 14, height: 11 }
  ];

  loading = false;
  status: 'Ready' | 'Generating' | 'Completed' | 'Failed' = 'Ready';
  imageDataUrl = '';
  apiResponse = 'Waiting for request...';

  constructor(private http: HttpClient) {}

  addRoom(): void {
    this.rooms.push({
      name: `Room ${this.rooms.length + 1}`,
      x: 0,
      y: 0,
      width: 12,
      height: 10
    });
  }

  removeRoom(index: number): void {
    this.rooms.splice(index, 1);
  }

  buildPayload() {
    return {
      selectedDesign: {
        name: this.designName,
        strategy: this.strategy,
        score: 100
      },
      land: {
        width: this.landWidth,
        length: this.landLength,
        unit: 'ft'
      },
      rooms: this.rooms,
      doors: [],
      windows: [],
      renderType: this.renderType,
      style: this.style,
      theme: this.theme,
      furnished: this.furnished
    };
  }

  async generateRender(): Promise<void> {
    if (!this.webhookUrl.trim()) {
      this.status = 'Failed';
      this.apiResponse = 'Webhook URL is empty.';
      return;
    }

    this.loading = true;
    this.status = 'Generating';
    this.apiResponse = 'Sending request to n8n...';

    try {
      const result = await firstValueFrom(
        this.http.post<RenderResponse>(
          this.webhookUrl.trim(),
          this.buildPayload()
        )
      );

      this.apiResponse = JSON.stringify({
        success: result.success,
        message: result.message,
        provider: result.provider,
        model: result.model,
        imageBase64Length: result.imageBase64?.length ?? 0
      }, null, 2);

      if (!result.success) {
        throw new Error(result.message || 'Image generation failed.');
      }

      if (result.imageDataUrl) {
        this.imageDataUrl = result.imageDataUrl;
      } else if (result.imageBase64) {
        this.imageDataUrl = `data:image/jpeg;base64,${result.imageBase64}`;
      } else {
        throw new Error('No image returned by n8n.');
      }

      this.status = 'Completed';
    } catch (error: any) {
      this.status = 'Failed';
      this.apiResponse =
        `Request failed.\n\n${error?.message || error}\n\n` +
        `If PowerShell works but Angular fails, check browser CORS and n8n webhook settings.`;
    } finally {
      this.loading = false;
    }
  }

  downloadImage(): void {
    if (!this.imageDataUrl) return;

    const anchor = document.createElement('a');
    anchor.href = this.imageDataUrl;
    anchor.download = `buildmind-render-${Date.now()}.jpg`;
    anchor.click();
  }

  clearResponse(): void {
    this.apiResponse = 'Waiting for request...';
  }

  get statusClass(): string {
    return this.status.toLowerCase();
  }
}
