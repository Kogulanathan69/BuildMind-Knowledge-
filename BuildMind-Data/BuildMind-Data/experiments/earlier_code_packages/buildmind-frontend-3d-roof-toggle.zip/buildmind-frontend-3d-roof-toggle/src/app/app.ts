import {
  ChangeDetectorRef,
  Component,
  ElementRef,
  OnDestroy,
  ViewChild
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

type ViewMode = 'interior' | 'exterior';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App implements OnDestroy {
  @ViewChild('threeContainer') threeContainer?: ElementRef<HTMLDivElement>;

  userMessage = '';
  loading = false;
  generated = false;
  errorMessage = '';

  selectedDesign: any = null;
  designOptions: any[] = [];
  validation: any = null;
  rooms: any[] = [];
  doors: any[] = [];
  windows: any[] = [];
  land: any = null;

  safeSvg: SafeHtml | null = null;
  activeOptionName = '';

  show3D = false;
  viewMode: ViewMode = 'interior';

  readonly samplePrompt =
    'I have a 40 x 60 ft land. I need 3 bedrooms, 2 bathrooms, ' +
    '1 car parking, a large kitchen and good ventilation.';

  private renderer?: THREE.WebGLRenderer;
  private scene?: THREE.Scene;
  private camera?: THREE.PerspectiveCamera;
  private controls?: OrbitControls;
  private animationId = 0;
  private resizeObserver?: ResizeObserver;

  private houseGroup?: THREE.Group;
  private roofGroup?: THREE.Group;
  private furnitureGroup?: THREE.Group;
  private exteriorGroup?: THREE.Group;

  constructor(
    private http: HttpClient,
    private sanitizer: DomSanitizer,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnDestroy(): void {
    this.disposeThree();
  }

  useSample(): void {
    this.userMessage = this.samplePrompt;
  }

  generatePlan(): void {
    if (!this.userMessage.trim()) {
      this.errorMessage = 'Please enter your house requirements.';
      return;
    }

    this.disposeThree();
    this.show3D = false;
    this.viewMode = 'interior';
    this.loading = true;
    this.generated = false;
    this.errorMessage = '';
    this.safeSvg = null;

    this.http.post<any>(
      '/api/webhook/buildmind-generate',
      { message: this.userMessage.trim() }
    ).subscribe({
      next: (response) => {
        const data = Array.isArray(response) ? response[0] : response;

        this.land = data?.land ?? { width: 40, length: 60, unit: 'ft' };
        this.selectedDesign = data?.selectedDesign ?? null;
        this.designOptions = data?.designOptions ?? [];
        this.validation = data?.validation ?? null;
        this.rooms = data?.rooms ?? [];
        this.doors = data?.doors ?? [];
        this.windows = data?.windows ?? [];
        this.activeOptionName = this.selectedDesign?.name ?? '';

        const svg =
          typeof data?.svgPreview === 'string' && data.svgPreview.includes('<svg')
            ? data.svgPreview
            : this.buildSvg(
                this.rooms,
                this.doors,
                this.windows,
                this.selectedDesign?.name ?? 'Selected Design',
                this.selectedDesign?.score ?? null
              );

        this.safeSvg = this.sanitizer.bypassSecurityTrustHtml(svg);

        this.loading = false;
        this.generated = true;
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error('BuildMind error:', err);
        this.loading = false;
        this.generated = false;
        this.errorMessage =
          'Unable to generate the plan. Make sure n8n is running and the workflow is published.';
        this.cdr.detectChanges();
      }
    });
  }

  selectDesign(option: any): void {
    this.disposeThree();
    this.show3D = false;
    this.viewMode = 'interior';

    this.activeOptionName = option.name;
    this.selectedDesign = {
      name: option.name,
      strategy: option.strategy ?? '',
      score: option.score ?? 0,
      explanations: option.explanations ?? []
    };

    this.rooms = option.rooms ?? [];
    this.doors = option.doors ?? [];
    this.windows = option.windows ?? [];
    this.validation = option.validation ?? this.validation;

    this.safeSvg = this.sanitizer.bypassSecurityTrustHtml(
      this.buildSvg(
        this.rooms,
        this.doors,
        this.windows,
        option.name,
        option.score ?? null
      )
    );

    window.scrollTo({ top: 0, behavior: 'smooth' });
    this.cdr.detectChanges();
  }

  open3D(mode: ViewMode = 'interior'): void {
    if (!this.rooms.length) {
      this.errorMessage = 'Generate and select a 2D design first.';
      return;
    }

    this.show3D = true;
    this.viewMode = mode;
    this.errorMessage = '';
    this.cdr.detectChanges();

    setTimeout(() => {
      this.initThree();
      this.applyViewMode();
    }, 0);
  }

  setViewMode(mode: ViewMode): void {
    this.viewMode = mode;

    if (!this.show3D) {
      this.open3D(mode);
      return;
    }

    this.applyViewMode();
  }

  show2D(): void {
    this.show3D = false;
    this.disposeThree();
  }

  resetDesign(): void {
    this.disposeThree();

    this.userMessage = '';
    this.loading = false;
    this.generated = false;
    this.errorMessage = '';
    this.selectedDesign = null;
    this.designOptions = [];
    this.validation = null;
    this.rooms = [];
    this.doors = [];
    this.windows = [];
    this.land = null;
    this.safeSvg = null;
    this.activeOptionName = '';
    this.show3D = false;
    this.viewMode = 'interior';

    this.cdr.detectChanges();
  }

  private initThree(): void {
    const container = this.threeContainer?.nativeElement;
    if (!container) return;

    this.disposeThree();
    container.innerHTML = '';

    const width = Math.max(container.clientWidth, 600);
    const height = Math.max(container.clientHeight, 520);

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0xf3f6fb);

    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 2000);

    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: false
    });

    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.setSize(width, height);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    container.appendChild(this.renderer.domElement);

    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.08;
    this.controls.enablePan = true;

    this.houseGroup = new THREE.Group();
    this.roofGroup = new THREE.Group();
    this.furnitureGroup = new THREE.Group();
    this.exteriorGroup = new THREE.Group();

    this.scene.add(
      this.houseGroup,
      this.roofGroup,
      this.furnitureGroup,
      this.exteriorGroup
    );

    this.addLights();
    this.addGround();
    this.addRoomsAndWalls();
    this.addFurniture();
    this.addRoof();
    this.addExteriorDetails();
    this.addGrid();

    this.resizeObserver = new ResizeObserver(() => {
      if (!this.renderer || !this.camera || !container) return;

      const w = Math.max(container.clientWidth, 320);
      const h = Math.max(container.clientHeight, 420);

      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h);
    });

    this.resizeObserver.observe(container);

    this.animate();
  }

  private applyViewMode(): void {
    if (!this.camera || !this.controls || !this.roofGroup || !this.furnitureGroup) return;

    const landWidth = Number(this.land?.width ?? 40);
    const landLength = Number(this.land?.length ?? 60);
    const maxSide = Math.max(landWidth, landLength);

    if (this.viewMode === 'interior') {
      this.roofGroup.visible = false;
      this.furnitureGroup.visible = true;

      this.camera.position.set(
        landWidth * 0.95,
        maxSide * 0.85,
        landLength * 0.95
      );

      this.controls.target.set(
        landWidth / 2,
        1.8,
        landLength / 2
      );
    } else {
      this.roofGroup.visible = true;
      this.furnitureGroup.visible = true;

      this.camera.position.set(
        landWidth * 1.25,
        maxSide * 0.65,
        landLength * 1.25
      );

      this.controls.target.set(
        landWidth / 2,
        2.2,
        landLength / 2
      );
    }

    this.controls.update();
  }

  private addLights(): void {
    if (!this.scene) return;

    const hemi = new THREE.HemisphereLight(0xffffff, 0x7c8799, 2.4);
    this.scene.add(hemi);

    const sun = new THREE.DirectionalLight(0xffffff, 3.0);
    sun.position.set(40, 80, 35);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    this.scene.add(sun);

    const fill = new THREE.DirectionalLight(0xffffff, 1.0);
    fill.position.set(-35, 25, -40);
    this.scene.add(fill);
  }

  private addGround(): void {
    if (!this.scene) return;

    const landWidth = Number(this.land?.width ?? 40);
    const landLength = Number(this.land?.length ?? 60);

    const geo = new THREE.PlaneGeometry(landWidth + 16, landLength + 16);
    const mat = new THREE.MeshStandardMaterial({
      color: 0xe6ebef,
      roughness: 0.95
    });

    const ground = new THREE.Mesh(geo, mat);
    ground.rotation.x = -Math.PI / 2;
    ground.position.set(landWidth / 2, -0.02, landLength / 2);
    ground.receiveShadow = true;

    this.scene.add(ground);
  }

  private addGrid(): void {
    if (!this.scene) return;

    const landWidth = Number(this.land?.width ?? 40);
    const landLength = Number(this.land?.length ?? 60);

    const size = Math.max(landWidth, landLength) * 1.5;
    const grid = new THREE.GridHelper(size, 30, 0xa8b2c1, 0xd3d9e2);
    grid.position.set(landWidth / 2, 0.01, landLength / 2);

    this.scene.add(grid);
  }

  private addRoomsAndWalls(): void {
    if (!this.houseGroup) return;

    const floorHeight = 0.16;
    const wallHeight = 3.1;
    const wallThickness = 0.18;

    for (const room of this.rooms) {
      const x = Number(room.x);
      const z = Number(room.y);
      const w = Number(room.width);
      const d = Number(room.height);

      const floor = new THREE.Mesh(
        new THREE.BoxGeometry(w, floorHeight, d),
        new THREE.MeshStandardMaterial({
          color: this.getRoomColor(room.name, room.type),
          roughness: 0.82
        })
      );

      floor.position.set(x + w / 2, floorHeight / 2, z + d / 2);
      floor.receiveShadow = true;
      this.houseGroup.add(floor);

      const wallMat = new THREE.MeshStandardMaterial({
        color: 0xf4f3ef,
        roughness: 0.78
      });

      this.addWall(
        x + w / 2, wallHeight / 2 + floorHeight, z,
        w, wallHeight, wallThickness, wallMat
      );

      this.addWall(
        x + w / 2, wallHeight / 2 + floorHeight, z + d,
        w, wallHeight, wallThickness, wallMat
      );

      this.addWall(
        x, wallHeight / 2 + floorHeight, z + d / 2,
        wallThickness, wallHeight, d, wallMat
      );

      this.addWall(
        x + w, wallHeight / 2 + floorHeight, z + d / 2,
        wallThickness, wallHeight, d, wallMat
      );
    }

    this.addDoorMarkers();
    this.addWindowMarkers();
  }

  private addWall(
    x: number,
    y: number,
    z: number,
    width: number,
    height: number,
    depth: number,
    material: THREE.Material
  ): void {
    if (!this.houseGroup) return;

    const mesh = new THREE.Mesh(
      new THREE.BoxGeometry(width, height, depth),
      material
    );

    mesh.position.set(x, y, z);
    mesh.castShadow = true;
    mesh.receiveShadow = true;

    this.houseGroup.add(mesh);
  }

  private addDoorMarkers(): void {
    if (!this.houseGroup) return;

    const mat = new THREE.MeshStandardMaterial({
      color: 0x8a5a34,
      roughness: 0.72
    });

    for (const door of this.doors) {
      const x = Number(door.x);
      const z = Number(door.y);
      const size = Number(door.width ?? 3);

      const mesh = door.orientation === 'vertical'
        ? new THREE.Mesh(new THREE.BoxGeometry(0.10, 2.2, size), mat)
        : new THREE.Mesh(new THREE.BoxGeometry(size, 2.2, 0.10), mat);

      mesh.position.set(
        door.orientation === 'vertical' ? x : x + size / 2,
        1.1,
        door.orientation === 'vertical' ? z + size / 2 : z
      );

      this.houseGroup.add(mesh);
    }
  }

  private addWindowMarkers(): void {
    if (!this.houseGroup) return;

    const mat = new THREE.MeshPhysicalMaterial({
      color: 0x75bfff,
      transparent: true,
      opacity: 0.55,
      roughness: 0.12,
      metalness: 0.02,
      transmission: 0.15
    });

    for (const win of this.windows) {
      const x = Number(win.x);
      const z = Number(win.y);
      const size = Number(win.width ?? 4);

      const mesh = win.orientation === 'vertical'
        ? new THREE.Mesh(new THREE.BoxGeometry(0.08, 1.25, size), mat)
        : new THREE.Mesh(new THREE.BoxGeometry(size, 1.25, 0.08), mat);

      mesh.position.set(
        win.orientation === 'vertical' ? x : x + size / 2,
        1.85,
        win.orientation === 'vertical' ? z + size / 2 : z
      );

      this.houseGroup.add(mesh);
    }
  }

  private addFurniture(): void {
    if (!this.furnitureGroup) return;

    for (const room of this.rooms) {
      const name = String(room.name || '').toLowerCase();

      if (name.includes('living')) {
        this.addSofa(room);
        this.addCoffeeTable(room);
      } else if (name.includes('master')) {
        this.addBed(room, true);
      } else if (name.includes('bedroom')) {
        this.addBed(room, false);
      } else if (name.includes('dining')) {
        this.addDiningSet(room);
      } else if (name.includes('kitchen')) {
        this.addKitchenCounter(room);
      } else if (name.includes('bath')) {
        this.addBathroomSet(room);
      }
    }
  }

  private addSofa(room: any): void {
    if (!this.furnitureGroup) return;

    const x = Number(room.x);
    const z = Number(room.y);
    const w = Math.min(Number(room.width) * 0.55, 7);
    const d = 2.1;

    const seatMat = new THREE.MeshStandardMaterial({
      color: 0x7b8794,
      roughness: 0.9
    });

    const seat = new THREE.Mesh(
      new THREE.BoxGeometry(w, 0.7, d),
      seatMat
    );

    seat.position.set(x + w / 2 + 0.8, 0.45, z + d / 2 + 0.9);
    seat.castShadow = true;

    const back = new THREE.Mesh(
      new THREE.BoxGeometry(w, 1.0, 0.35),
      seatMat
    );

    back.position.set(x + w / 2 + 0.8, 1.05, z + 0.9);

    this.furnitureGroup.add(seat, back);
  }

  private addCoffeeTable(room: any): void {
    if (!this.furnitureGroup) return;

    const x = Number(room.x);
    const z = Number(room.y);
    const w = Number(room.width);

    const table = new THREE.Mesh(
      new THREE.BoxGeometry(Math.min(w * 0.28, 3.8), 0.18, 1.7),
      new THREE.MeshStandardMaterial({
        color: 0x9b6b43,
        roughness: 0.72
      })
    );

    table.position.set(
      x + Math.min(w * 0.65, w - 2),
      0.5,
      z + 3.2
    );

    table.castShadow = true;
    this.furnitureGroup.add(table);
  }

  private addBed(room: any, master: boolean): void {
    if (!this.furnitureGroup) return;

    const x = Number(room.x);
    const z = Number(room.y);
    const rw = Number(room.width);
    const rd = Number(room.height);

    const bw = master ? Math.min(6, rw - 1.5) : Math.min(4.5, rw - 1.5);
    const bd = Math.min(6.5, rd - 1.5);

    const base = new THREE.Mesh(
      new THREE.BoxGeometry(bw, 0.55, bd),
      new THREE.MeshStandardMaterial({
        color: 0xcab08d,
        roughness: 0.85
      })
    );

    base.position.set(x + rw / 2, 0.45, z + rd / 2);
    base.castShadow = true;

    const mattress = new THREE.Mesh(
      new THREE.BoxGeometry(bw - 0.2, 0.32, bd - 0.25),
      new THREE.MeshStandardMaterial({
        color: master ? 0xe8eefc : 0xf1f3f8,
        roughness: 0.92
      })
    );

    mattress.position.set(x + rw / 2, 0.88, z + rd / 2);

    const head = new THREE.Mesh(
      new THREE.BoxGeometry(bw, 1.4, 0.25),
      new THREE.MeshStandardMaterial({
        color: 0x8f6c53,
        roughness: 0.8
      })
    );

    head.position.set(x + rw / 2, 1.2, z + rd / 2 - bd / 2);

    this.furnitureGroup.add(base, mattress, head);
  }

  private addDiningSet(room: any): void {
    if (!this.furnitureGroup) return;

    const x = Number(room.x);
    const z = Number(room.y);
    const rw = Number(room.width);
    const rd = Number(room.height);

    const cx = x + rw / 2;
    const cz = z + rd / 2;

    const table = new THREE.Mesh(
      new THREE.BoxGeometry(Math.min(4.8, rw - 1.5), 0.18, 2.4),
      new THREE.MeshStandardMaterial({
        color: 0x9b6b43,
        roughness: 0.75
      })
    );

    table.position.set(cx, 0.85, cz);
    table.castShadow = true;
    this.furnitureGroup.add(table);

    const chairMat = new THREE.MeshStandardMaterial({
      color: 0x6d5a48,
      roughness: 0.82
    });

    const positions = [
      [cx - 1.8, cz],
      [cx + 1.8, cz],
      [cx, cz - 1.8],
      [cx, cz + 1.8]
    ];

    for (const [px, pz] of positions) {
      const chair = new THREE.Mesh(
        new THREE.BoxGeometry(0.8, 0.8, 0.8),
        chairMat
      );
      chair.position.set(px, 0.4, pz);
      this.furnitureGroup.add(chair);
    }
  }

  private addKitchenCounter(room: any): void {
    if (!this.furnitureGroup) return;

    const x = Number(room.x);
    const z = Number(room.y);
    const rw = Number(room.width);
    const rd = Number(room.height);

    const mat = new THREE.MeshStandardMaterial({
      color: 0xe6e0d6,
      roughness: 0.75
    });

    const counter1 = new THREE.Mesh(
      new THREE.BoxGeometry(Math.max(3, rw - 1.2), 0.9, 1.2),
      mat
    );

    counter1.position.set(x + rw / 2, 0.45, z + 0.8);

    const counter2 = new THREE.Mesh(
      new THREE.BoxGeometry(1.2, 0.9, Math.max(3, rd * 0.55)),
      mat
    );

    counter2.position.set(x + 0.8, 0.45, z + rd * 0.55);

    this.furnitureGroup.add(counter1, counter2);
  }

  private addBathroomSet(room: any): void {
    if (!this.furnitureGroup) return;

    const x = Number(room.x);
    const z = Number(room.y);
    const rw = Number(room.width);
    const rd = Number(room.height);

    const ceramic = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.45
    });

    const toilet = new THREE.Mesh(
      new THREE.CylinderGeometry(0.55, 0.65, 0.65, 24),
      ceramic
    );

    toilet.position.set(
      x + Math.min(1.2, rw / 3),
      0.35,
      z + Math.min(1.4, rd / 3)
    );

    const sink = new THREE.Mesh(
      new THREE.BoxGeometry(1.1, 0.25, 0.75),
      ceramic
    );

    sink.position.set(
      x + rw - Math.min(1.1, rw / 3),
      0.95,
      z + 1.0
    );

    this.furnitureGroup.add(toilet, sink);
  }

  private addRoof(): void {
    if (!this.roofGroup) return;

    const landWidth = Number(this.land?.width ?? 40);
    const landLength = Number(this.land?.length ?? 60);
    const wallHeight = 3.1;
    const roofY = wallHeight + 0.45;

    // Simple dual-slope concept roof
    const roofMat = new THREE.MeshStandardMaterial({
      color: 0xa65338,
      roughness: 0.8,
      side: THREE.DoubleSide
    });

    const half = landWidth / 2;
    const slopeRise = Math.max(2.2, landWidth * 0.12);

    const shapeLeft = new THREE.Shape();
    shapeLeft.moveTo(0, 0);
    shapeLeft.lineTo(half, slopeRise);
    shapeLeft.lineTo(half, slopeRise + 0.15);
    shapeLeft.lineTo(0, 0.15);
    shapeLeft.closePath();

    const leftGeo = new THREE.ExtrudeGeometry(shapeLeft, {
      depth: landLength,
      bevelEnabled: false
    });

    const left = new THREE.Mesh(leftGeo, roofMat);
    left.position.set(0, roofY, 0);
    left.castShadow = true;
    this.roofGroup.add(left);

    const shapeRight = new THREE.Shape();
    shapeRight.moveTo(0, slopeRise);
    shapeRight.lineTo(half, 0);
    shapeRight.lineTo(half, 0.15);
    shapeRight.lineTo(0, slopeRise + 0.15);
    shapeRight.closePath();

    const rightGeo = new THREE.ExtrudeGeometry(shapeRight, {
      depth: landLength,
      bevelEnabled: false
    });

    const right = new THREE.Mesh(rightGeo, roofMat);
    right.position.set(half, roofY, 0);
    right.castShadow = true;
    this.roofGroup.add(right);
  }

  private addExteriorDetails(): void {
    if (!this.exteriorGroup) return;

    const landWidth = Number(this.land?.width ?? 40);
    const landLength = Number(this.land?.length ?? 60);

    // Front step / porch slab
    const porch = new THREE.Mesh(
      new THREE.BoxGeometry(Math.min(10, landWidth * 0.35), 0.18, 2.2),
      new THREE.MeshStandardMaterial({
        color: 0xc8c2b8,
        roughness: 0.9
      })
    );

    porch.position.set(landWidth * 0.3, 0.09, -1.0);
    this.exteriorGroup.add(porch);

    // Simple front path
    const path = new THREE.Mesh(
      new THREE.BoxGeometry(3.5, 0.05, 7),
      new THREE.MeshStandardMaterial({
        color: 0xb8b8b8,
        roughness: 0.95
      })
    );

    path.position.set(landWidth * 0.3, 0.025, -4.5);
    this.exteriorGroup.add(path);

    // Small decorative garden patches
    const grassMat = new THREE.MeshStandardMaterial({
      color: 0x8fbd75,
      roughness: 1
    });

    const grass1 = new THREE.Mesh(
      new THREE.BoxGeometry(Math.max(4, landWidth * 0.18), 0.04, 5),
      grassMat
    );

    grass1.position.set(landWidth * 0.1, 0.02, -3.8);

    const grass2 = grass1.clone();
    grass2.position.set(landWidth * 0.5, 0.02, -3.8);

    this.exteriorGroup.add(grass1, grass2);
  }

  private animate = (): void => {
    if (!this.renderer || !this.scene || !this.camera) return;

    this.animationId = requestAnimationFrame(this.animate);
    this.controls?.update();
    this.renderer.render(this.scene, this.camera);
  };

  private disposeThree(): void {
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
      this.animationId = 0;
    }

    this.resizeObserver?.disconnect();
    this.resizeObserver = undefined;

    this.controls?.dispose();
    this.controls = undefined;

    if (this.scene) {
      this.scene.traverse((obj) => {
        const mesh = obj as THREE.Mesh;

        if (mesh.geometry) {
          mesh.geometry.dispose();
        }

        const material = mesh.material as THREE.Material | THREE.Material[] | undefined;

        if (Array.isArray(material)) {
          material.forEach((m) => m.dispose());
        } else {
          material?.dispose();
        }
      });
    }

    this.renderer?.dispose();

    const container = this.threeContainer?.nativeElement;
    if (container) {
      container.innerHTML = '';
    }

    this.renderer = undefined;
    this.scene = undefined;
    this.camera = undefined;
    this.houseGroup = undefined;
    this.roofGroup = undefined;
    this.furnitureGroup = undefined;
    this.exteriorGroup = undefined;
  }

  private getRoomColor(name: string, type?: string): number {
    const n = String(name || '').toLowerCase();
    const t = String(type || '').toLowerCase();

    if (n.includes('living')) return 0xffefbf;
    if (n.includes('kitchen')) return 0xffd7b5;
    if (n.includes('dining')) return 0xfff0bf;
    if (n.includes('master')) return 0xcddaff;
    if (n.includes('bedroom')) return 0xdfe7ff;
    if (n.includes('bath')) return 0xcdefff;
    if (n.includes('parking')) return 0xd7d7d7;
    if (n.includes('corridor')) return 0xeeeeee;
    if (n.includes('backyard') || n.includes('utility') || t === 'open-space') return 0xdff4d9;

    return 0xe9edf4;
  }

  private buildSvg(
    rooms: any[],
    doors: any[],
    windows: any[],
    name: string,
    score: number | null
  ): string {
    const lw = Number(this.land?.width ?? 40);
    const ll = Number(this.land?.length ?? 60);
    const unit = String(this.land?.unit ?? 'ft');

    const W = 900;
    const H = 760;
    const L = 70;
    const T = 100;
    const R = 150;
    const B = 70;

    const s = Math.min((W - L - R) / lw, (H - T - B) / ll);

    const pxX = (x: number) => L + x * s;
    const pxY = (y: number) => T + y * s;

    const esc = (v: any) =>
      String(v ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');

    const color = (r: any) => {
      const n = String(r.name || '').toLowerCase();

      if (n.includes('backyard') || n.includes('utility')) return '#edf8e8';
      if (n.includes('living')) return '#fff5dc';
      if (n.includes('kitchen')) return '#ffeede';
      if (n.includes('dining')) return '#fff8dc';
      if (n.includes('master')) return '#e8efff';
      if (n.includes('bedroom')) return '#f0f4ff';
      if (n.includes('bath')) return '#e4f6ff';
      if (n.includes('parking')) return '#eeeeee';
      if (n.includes('corridor')) return '#f8f8f8';

      return '#f7f7f7';
    };

    let svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
      <rect width="100%" height="100%" fill="white"/>
      <text x="${W / 2}" y="32" text-anchor="middle" font-size="24" font-family="Arial" font-weight="bold">BuildMind - AI Generated 2D Floor Plan</text>
      <text x="${W / 2}" y="55" text-anchor="middle" font-size="12" font-family="Arial" fill="#667085">Interactive Design Preview</text>
      <text x="${L}" y="80" font-size="14" font-family="Arial" font-weight="bold" fill="#3157ff">${esc(name)}</text>
      ${score !== null ? `<text x="${L + 180}" y="80" font-size="13" font-family="Arial" font-weight="bold" fill="#059669">AI Score: ${score}</text>` : ''}
      <text x="${L + (lw * s) / 2}" y="${T - 18}" text-anchor="middle" font-size="13" font-family="Arial" font-weight="bold">FRONT / ROAD</text>
      <rect x="${L}" y="${T}" width="${lw * s}" height="${ll * s}" fill="white" stroke="#111" stroke-width="5"/>`;

    for (const r of rooms) {
      const x = pxX(r.x);
      const y = pxY(r.y);
      const w = r.width * s;
      const h = r.height * s;
      const fs = r.width * r.height < 45 ? 9 : 11;

      svg += `<g>
        <rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${color(r)}" stroke="#1f2937" stroke-width="2"/>
        <text x="${x + w / 2}" y="${y + h / 2 - 5}" text-anchor="middle" font-family="Arial" font-size="${fs}" font-weight="bold">${esc(r.name)}</text>
        <text x="${x + w / 2}" y="${y + h / 2 + 12}" text-anchor="middle" font-family="Arial" font-size="${Math.max(fs - 1, 8)}">${r.width} × ${r.height} ${esc(unit)}</text>
      </g>`;
    }

    for (const d of doors) {
      const x = pxX(d.x);
      const y = pxY(d.y);
      const z = (d.width ?? 3) * s;

      if (d.orientation === 'vertical') {
        svg += `<line x1="${x}" y1="${y}" x2="${x}" y2="${y + z}" stroke="white" stroke-width="7"/>
          <line x1="${x}" y1="${y}" x2="${x + z}" y2="${y}" stroke="#92400e" stroke-width="2"/>`;
      } else {
        svg += `<line x1="${x}" y1="${y}" x2="${x + z}" y2="${y}" stroke="white" stroke-width="7"/>
          <line x1="${x}" y1="${y}" x2="${x}" y2="${y + z}" stroke="#92400e" stroke-width="2"/>`;
      }
    }

    for (const w of windows) {
      const x = pxX(w.x);
      const y = pxY(w.y);
      const z = (w.width ?? 4) * s;

      if (w.orientation === 'vertical') {
        svg += `<line x1="${x}" y1="${y}" x2="${x}" y2="${y + z}" stroke="#2563eb" stroke-width="4"/>`;
      } else {
        svg += `<line x1="${x}" y1="${y}" x2="${x + z}" y2="${y}" stroke="#2563eb" stroke-width="4"/>`;
      }
    }

    svg += `<text x="${W / 2}" y="${H - 18}" text-anchor="middle" font-family="Arial" font-size="10" fill="#667085">BuildMind Concept Plan — Final construction drawings require professional review.</text></svg>`;

    return svg;
  }
}
