# BuildMind Frontend 3D — Interior + Exterior View

This version adds the two 3D modes requested:

1. Interior / Open Roof View
2. Exterior / Full House View with Roof

It also includes:
- Design A / B / C selection
- n8n production webhook integration
- 2D SVG preview
- Three.js orbit controls
- Basic procedural furniture
- Door/window markers
- Simple dual-slope roof
- Front porch/path/garden concept details

## Run

```powershell
npm.cmd install
npm.cmd start
```

Open:

http://localhost:4200

n8n must be running at:

http://localhost:5678

The Angular proxy forwards `/api` requests to n8n.

## n8n webhook

Use:

POST /webhook/buildmind-generate

Webhook path:

buildmind-generate

The workflow must be published/active.

## 3D modes

### Interior / Open Roof
- roof hidden
- furniture visible
- rooms visible from above
- rotate / zoom / pan

### Exterior / Full House
- roof visible
- complete outside form visible
- rotate / zoom / pan

## Note

This is still a concept-level 3D prototype.
Proper wall cut-outs, realistic GLTF furniture, advanced roofs, materials,
multiple floors, structural logic and construction-ready geometry are future phases.
