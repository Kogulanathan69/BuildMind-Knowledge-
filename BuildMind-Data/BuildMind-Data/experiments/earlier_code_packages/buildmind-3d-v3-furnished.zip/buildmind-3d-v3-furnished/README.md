# BuildMind 3D V3 Furnished

This version is designed to move much closer to the furnished isometric reference style.

## Main upgrades
- Furnished open-roof isometric view
- Full roof-on exterior view
- White walls with dark top edge/caps
- Wood-like floors in living/dining/bedrooms
- Tiled bathroom/kitchen look
- Sofa with cushions
- TV + TV unit
- Rug + coffee table
- Detailed beds with mattress, duvet, pillows, headboard
- Side tables + wardrobes
- Dining table + chairs
- Kitchen counters, upper cabinets, island and hob
- Toilet, sink, tap and shower glass
- Porch/deck, path, lawns, plants, railing
- Better lighting and shadows
- Day / Warm mode
- Furniture toggle
- Room label toggle
- 2D / furnished interior / exterior modes
- Existing n8n webhook integration

## Run
```powershell
npm.cmd install
npm.cmd start
```

Open:
http://localhost:4200

n8n should run on:
http://localhost:5678

Published webhook:
POST /webhook/buildmind-generate

## Important
This is a procedural Three.js renderer.
It is much closer to the reference style, but exact photorealistic output still requires professional 3D assets (GLTF),
PBR materials/textures and stronger wall-opening/geometry logic.
