
import {
  ChangeDetectorRef,
  Component,
  ElementRef,
  OnDestroy,
  ViewChild
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

type ViewMode = 'interior' | 'exterior';
type LightingMode = 'day' | 'warm';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App implements OnDestroy {
  @ViewChild('threeContainer') threeContainer?: ElementRef<HTMLDivElement>;

  userMessage = '';
  loading = false;
  generated = false;
  errorMessage = '';

  selectedDesign: any = null;
  designOptions: any[] = [];
  validation: any = null;
  rooms: any[] = [];
  doors: any[] = [];
  windows: any[] = [];
  land: any = null;

  safeSvg: SafeHtml | null = null;
  activeOptionName = '';

  show3D = false;
  viewMode: ViewMode = 'interior';
  lightingMode: LightingMode = 'day';
  furnitureVisible = true;
  labelsVisible = false;

  readonly samplePrompt =
    'I have a 40 x 60 ft land. I need 3 bedrooms, 2 bathrooms, ' +
    '1 car parking, a large kitchen and good ventilation.';

  private renderer?: THREE.WebGLRenderer;
  private scene?: THREE.Scene;
  private camera?: THREE.PerspectiveCamera;
  private controls?: OrbitControls;
  private animationId = 0;
  private resizeObserver?: ResizeObserver;

  private houseGroup = new THREE.Group();
  private roofGroup = new THREE.Group();
  private furnitureGroup = new THREE.Group();
  private decorGroup = new THREE.Group();
  private labelGroup = new THREE.Group();
  private lightGroup = new THREE.Group();

  constructor(
    private http: HttpClient,
    private sanitizer: DomSanitizer,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnDestroy(): void {
    this.disposeThree();
  }

  useSample(): void {
    this.userMessage = this.samplePrompt;
  }

  generatePlan(): void {
    if (!this.userMessage.trim()) {
      this.errorMessage = 'Please enter your house requirements.';
      return;
    }

    this.disposeThree();
    this.loading = true;
    this.generated = false;
    this.errorMessage = '';
    this.show3D = false;
    this.safeSvg = null;

    this.http.post<any>(
      '/api/webhook/buildmind-generate',
      { message: this.userMessage.trim() }
    ).subscribe({
      next: (response) => {
        const data = Array.isArray(response) ? response[0] : response;

        this.land = data?.land ?? { width: 40, length: 60, unit: 'ft' };
        this.selectedDesign = data?.selectedDesign ?? null;
        this.designOptions = data?.designOptions ?? [];
        this.validation = data?.validation ?? null;
        this.rooms = data?.rooms ?? [];
        this.doors = data?.doors ?? [];
        this.windows = data?.windows ?? [];
        this.activeOptionName = this.selectedDesign?.name ?? '';

        const svg =
          typeof data?.svgPreview === 'string' && data.svgPreview.includes('<svg')
            ? data.svgPreview
            : this.buildSvg(
                this.rooms,
                this.doors,
                this.windows,
                this.selectedDesign?.name ?? 'Selected Design',
                this.selectedDesign?.score ?? null
              );

        this.safeSvg = this.sanitizer.bypassSecurityTrustHtml(svg);
        this.loading = false;
        this.generated = true;
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error(err);
        this.loading = false;
        this.generated = false;
        this.errorMessage =
          'Unable to generate the plan. Make sure n8n is running and the workflow is published.';
        this.cdr.detectChanges();
      }
    });
  }

  selectDesign(option: any): void {
    this.disposeThree();
    this.show3D = false;

    this.activeOptionName = option.name;
    this.selectedDesign = {
      name: option.name,
      strategy: option.strategy ?? '',
      score: option.score ?? 0,
      explanations: option.explanations ?? []
    };

    this.rooms = option.rooms ?? [];
    this.doors = option.doors ?? [];
    this.windows = option.windows ?? [];
    this.validation = option.validation ?? this.validation;

    this.safeSvg = this.sanitizer.bypassSecurityTrustHtml(
      this.buildSvg(
        this.rooms,
        this.doors,
        this.windows,
        option.name,
        option.score ?? null
      )
    );

    window.scrollTo({ top: 0, behavior: 'smooth' });
    this.cdr.detectChanges();
  }

  show2D(): void {
    this.show3D = false;
    this.disposeThree();
  }

  open3D(mode: ViewMode = 'interior'): void {
    if (!this.rooms.length) {
      this.errorMessage = 'Generate and select a 2D design first.';
      return;
    }

    this.show3D = true;
    this.viewMode = mode;
    this.errorMessage = '';
    this.cdr.detectChanges();

    setTimeout(() => {
      this.initThree();
      this.applyViewMode();
      this.applyLighting();
    }, 0);
  }

  setViewMode(mode: ViewMode): void {
    this.viewMode = mode;

    if (!this.show3D) {
      this.open3D(mode);
      return;
    }

    this.applyViewMode();
  }

  setLighting(mode: LightingMode): void {
    this.lightingMode = mode;
    this.applyLighting();
  }

  toggleFurniture(): void {
    this.furnitureVisible = !this.furnitureVisible;
    this.furnitureGroup.visible = this.furnitureVisible;
  }

  toggleLabels(): void {
    this.labelsVisible = !this.labelsVisible;
    this.labelGroup.visible = this.labelsVisible;
  }

  resetCamera(): void {
    this.applyViewMode();
  }

  resetDesign(): void {
    this.disposeThree();

    this.userMessage = '';
    this.loading = false;
    this.generated = false;
    this.errorMessage = '';
    this.selectedDesign = null;
    this.designOptions = [];
    this.validation = null;
    this.rooms = [];
    this.doors = [];
    this.windows = [];
    this.land = null;
    this.safeSvg = null;
    this.activeOptionName = '';
    this.show3D = false;
    this.viewMode = 'interior';
    this.lightingMode = 'day';
    this.furnitureVisible = true;
    this.labelsVisible = false;
    this.cdr.detectChanges();
  }

  // ==============================================================
  // THREE.JS V3 - furnished architectural dollhouse style
  // ==============================================================

  private initThree(): void {
    const container = this.threeContainer?.nativeElement;
    if (!container) return;

    this.disposeThree();
    container.innerHTML = '';

    const width = Math.max(container.clientWidth, 800);
    const height = Math.max(container.clientHeight, 660);

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0xf7f7f5);

    this.camera = new THREE.PerspectiveCamera(36, width / height, 0.1, 3000);

    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    this.renderer.setSize(width, height);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;

    container.appendChild(this.renderer.domElement);

    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.08;
    this.controls.enablePan = true;
    this.controls.minPolarAngle = 0.28;
    this.controls.maxPolarAngle = Math.PI / 2.03;

    this.houseGroup = new THREE.Group();
    this.roofGroup = new THREE.Group();
    this.furnitureGroup = new THREE.Group();
    this.decorGroup = new THREE.Group();
    this.labelGroup = new THREE.Group();
    this.lightGroup = new THREE.Group();

    this.scene.add(
      this.houseGroup,
      this.roofGroup,
      this.furnitureGroup,
      this.decorGroup,
      this.labelGroup,
      this.lightGroup
    );

    this.buildSite();
    this.buildHouse();
    this.buildFurniture();
    this.buildDecor();
    this.buildRoof();
    this.buildLabels();
    this.addLights();

    this.furnitureGroup.visible = this.furnitureVisible;
    this.labelGroup.visible = this.labelsVisible;

    this.resizeObserver = new ResizeObserver(() => {
      if (!this.renderer || !this.camera || !container) return;
      const w = Math.max(container.clientWidth, 360);
      const h = Math.max(container.clientHeight, 500);
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h);
    });
    this.resizeObserver.observe(container);

    this.animate();
  }

  private applyViewMode(): void {
    if (!this.camera || !this.controls) return;

    const lw = Number(this.land?.width ?? 40);
    const ll = Number(this.land?.length ?? 60);
    const m = Math.max(lw, ll);

    if (this.viewMode === 'interior') {
      this.roofGroup.visible = false;
      this.camera.position.set(lw * 1.05, m * 1.05, ll * 1.05);
      this.controls.target.set(lw / 2, 1.25, ll / 2);
    } else {
      this.roofGroup.visible = true;
      this.camera.position.set(lw * 1.35, m * 0.72, ll * 1.30);
      this.controls.target.set(lw / 2, 2.1, ll / 2);
    }

    this.controls.update();
  }

  private applyLighting(): void {
    if (!this.scene) return;

    this.lightGroup.clear();

    if (this.lightingMode === 'warm') {
      this.scene.background = new THREE.Color(0xf2e7db);
      if (this.renderer) this.renderer.toneMappingExposure = 0.98;
    } else {
      this.scene.background = new THREE.Color(0xf7f7f5);
      if (this.renderer) this.renderer.toneMappingExposure = 1.08;
    }

    this.addLights();
  }

  private addLights(): void {
    const warm = this.lightingMode === 'warm';

    const hemi = new THREE.HemisphereLight(
      warm ? 0xffecd2 : 0xffffff,
      0x858d99,
      warm ? 1.45 : 1.9
    );
    this.lightGroup.add(hemi);

    const sun = new THREE.DirectionalLight(
      warm ? 0xffd1a3 : 0xffffff,
      warm ? 3.0 : 3.5
    );
    sun.position.set(50, 80, 35);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    sun.shadow.camera.left = -120;
    sun.shadow.camera.right = 120;
    sun.shadow.camera.top = 120;
    sun.shadow.camera.bottom = -120;
    this.lightGroup.add(sun);

    const fill = new THREE.DirectionalLight(
      warm ? 0xfff0df : 0xeaf2ff,
      0.8
    );
    fill.position.set(-40, 35, -35);
    this.lightGroup.add(fill);
  }

  private buildSite(): void {
    const lw = Number(this.land?.width ?? 40);
    const ll = Number(this.land?.length ?? 60);

    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(lw + 30, ll + 30),
      new THREE.MeshStandardMaterial({
        color: 0xf2f2ef,
        roughness: 1
      })
    );
    ground.rotation.x = -Math.PI / 2;
    ground.position.set(lw / 2, -0.06, ll / 2);
    ground.receiveShadow = true;
    this.scene?.add(ground);

    const slab = new THREE.Mesh(
      new THREE.BoxGeometry(lw + 1.0, 0.18, ll + 1.0),
      new THREE.MeshStandardMaterial({
        color: 0xd8d8d4,
        roughness: 0.92
      })
    );
    slab.position.set(lw / 2, 0.02, ll / 2);
    slab.receiveShadow = true;
    this.decorGroup.add(slab);
  }

  private buildHouse(): void {
    const floorT = 0.18;
    const wallH = 3.2;
    const extT = 0.25;
    const intT = 0.18;

    for (const room of this.rooms) {
      const x = Number(room.x);
      const z = Number(room.y);
      const w = Number(room.width);
      const d = Number(room.height);

      const floor = new THREE.Mesh(
        new THREE.BoxGeometry(w, floorT, d),
        this.makeFloorMaterial(room.name)
      );
      floor.position.set(x + w / 2, floorT / 2, z + d / 2);
      floor.receiveShadow = true;
      this.houseGroup.add(floor);

      // Walls
      const wallMat = new THREE.MeshStandardMaterial({
        color: 0xf6f4ef,
        roughness: 0.88
      });

      const capMat = new THREE.MeshStandardMaterial({
        color: 0x3d434a,
        roughness: 0.65
      });

      this.addWall(room, 'top', wallH, extT, wallMat, capMat);
      this.addWall(room, 'bottom', wallH, extT, wallMat, capMat);
      this.addWall(room, 'left', wallH, intT, wallMat, capMat);
      this.addWall(room, 'right', wallH, intT, wallMat, capMat);

      // skirting/baseboard
      this.addBaseboard(room, 'top');
      this.addBaseboard(room, 'bottom');
      this.addBaseboard(room, 'left');
      this.addBaseboard(room, 'right');
    }

    this.addDoorObjects();
    this.addWindowObjects();
  }

  private addWall(
    room: any,
    side: 'top' | 'bottom' | 'left' | 'right',
    wallH: number,
    thickness: number,
    material: THREE.Material,
    capMaterial: THREE.Material
  ): void {
    const rx = Number(room.x);
    const rz = Number(room.y);
    const rw = Number(room.width);
    const rd = Number(room.height);

    let w = 0, d = 0, px = 0, pz = 0;

    if (side === 'top') {
      w = rw; d = thickness; px = rx + rw / 2; pz = rz;
    } else if (side === 'bottom') {
      w = rw; d = thickness; px = rx + rw / 2; pz = rz + rd;
    } else if (side === 'left') {
      w = thickness; d = rd; px = rx; pz = rz + rd / 2;
    } else {
      w = thickness; d = rd; px = rx + rw; pz = rz + rd / 2;
    }

    const wall = new THREE.Mesh(
      new THREE.BoxGeometry(w, wallH, d),
      material
    );
    wall.position.set(px, wallH / 2 + 0.18, pz);
    wall.castShadow = true;
    wall.receiveShadow = true;
    this.houseGroup.add(wall);

    // dark top cap - gives reference-image-like crisp wall outline
    const cap = new THREE.Mesh(
      new THREE.BoxGeometry(w + 0.02, 0.08, d + 0.02),
      capMaterial
    );
    cap.position.set(px, wallH + 0.22, pz);
    this.houseGroup.add(cap);
  }

  private addBaseboard(room: any, side: 'top' | 'bottom' | 'left' | 'right'): void {
    const rx = Number(room.x), rz = Number(room.y);
    const rw = Number(room.width), rd = Number(room.height);

    const mat = new THREE.MeshStandardMaterial({
      color: 0xd9d4ca,
      roughness: 0.85
    });

    let geo: THREE.BoxGeometry;
    let px = 0, pz = 0;

    if (side === 'top' || side === 'bottom') {
      geo = new THREE.BoxGeometry(rw, 0.10, 0.05);
      px = rx + rw / 2;
      pz = side === 'top' ? rz + 0.12 : rz + rd - 0.12;
    } else {
      geo = new THREE.BoxGeometry(0.05, 0.10, rd);
      px = side === 'left' ? rx + 0.12 : rx + rw - 0.12;
      pz = rz + rd / 2;
    }

    const b = new THREE.Mesh(geo, mat);
    b.position.set(px, 0.28, pz);
    this.houseGroup.add(b);
  }

  private makeFloorMaterial(name: string): THREE.Material {
    const n = String(name).toLowerCase();

    if (n.includes('bath')) {
      return new THREE.MeshStandardMaterial({ color: 0xd7e3e5, roughness: 0.62 });
    }

    if (n.includes('kitchen')) {
      return new THREE.MeshStandardMaterial({ color: 0xe5e0d8, roughness: 0.68 });
    }

    if (n.includes('living') || n.includes('dining') || n.includes('bedroom') || n.includes('master')) {
      return new THREE.MeshStandardMaterial({ color: 0xb99269, roughness: 0.72 });
    }

    if (n.includes('parking')) {
      return new THREE.MeshStandardMaterial({ color: 0xc7c9cc, roughness: 0.92 });
    }

    if (n.includes('backyard') || n.includes('utility')) {
      return new THREE.MeshStandardMaterial({ color: 0xcfe0c4, roughness: 1 });
    }

    return new THREE.MeshStandardMaterial({ color: 0xe1ddd5, roughness: 0.8 });
  }

  private buildFurniture(): void {
    for (const room of this.rooms) {
      const n = String(room.name || '').toLowerCase();

      if (n.includes('living')) this.furnishLiving(room);
      else if (n.includes('master')) this.furnishBedroom(room, true);
      else if (n.includes('bedroom')) this.furnishBedroom(room, false);
      else if (n.includes('dining')) this.furnishDining(room);
      else if (n.includes('kitchen')) this.furnishKitchen(room);
      else if (n.includes('bath')) this.furnishBathroom(room);
    }
  }

  private furnishLiving(room: any): void {
    const x = +room.x, z = +room.y, w = +room.width, d = +room.height;

    const sofaMat = new THREE.MeshStandardMaterial({ color: 0xd0cbc4, roughness: 0.92 });
    const cushionMat = new THREE.MeshStandardMaterial({ color: 0xb9afa3, roughness: 0.95 });
    const wood = new THREE.MeshStandardMaterial({ color: 0x704b32, roughness: 0.74 });
    const black = new THREE.MeshStandardMaterial({ color: 0x222426, roughness: 0.3 });

    const sofaW = Math.min(7.2, w * 0.48);
    const seat = this.box(sofaW, 0.55, 2.0, sofaMat, x + 1.2 + sofaW/2, 0.45, z + 2.3);
    const back = this.box(sofaW, 1.1, 0.35, sofaMat, seat.position.x, 1.10, z + 1.45);

    const armL = this.box(0.42, 0.86, 2.0, sofaMat, seat.position.x - sofaW/2, 0.66, z + 2.3);
    const armR = this.box(0.42, 0.86, 2.0, sofaMat, seat.position.x + sofaW/2, 0.66, z + 2.3);

    for (const off of [-sofaW * .25, 0, sofaW * .25]) {
      this.box(1.3, 0.24, 0.92, cushionMat, seat.position.x + off, 0.86, z + 2.3);
    }

    const coffee = this.box(Math.min(3.8, w*.28), 0.20, 1.7, wood, x + w*.58, 0.52, z + Math.min(4.5, d*.42));
    const tvStand = this.box(Math.min(5.0, w*.36), 0.58, 0.65, wood, x + w/2, 0.35, z + d - 0.75);
    const tv = this.box(Math.min(4.4, w*.32), 2.3, 0.10, black, x + w/2, 1.75, z + d - 0.42);

    [seat,back,armL,armR,coffee,tvStand,tv].forEach(m => this.furnitureGroup.add(m));

    // rug
    const rug = new THREE.Mesh(
      new THREE.BoxGeometry(Math.min(8,w*.60), 0.04, Math.min(5,d*.45)),
      new THREE.MeshStandardMaterial({ color: 0xb9b1a8, roughness: 1 })
    );
    rug.position.set(x + w*.54, 0.22, z + d*.48);
    this.furnitureGroup.add(rug);
  }

  private furnishBedroom(room: any, master: boolean): void {
    const x = +room.x, z = +room.y, w = +room.width, d = +room.height;

    const wood = new THREE.MeshStandardMaterial({ color: 0x78533b, roughness: .82 });
    const linen = new THREE.MeshStandardMaterial({ color: 0xf3f1ec, roughness: .96 });
    const duvet = new THREE.MeshStandardMaterial({ color: master ? 0x72767c : 0x8fa2ba, roughness: .95 });

    const bw = Math.min(master ? 6.2 : 4.8, Math.max(3.6, w - 1.5));
    const bd = Math.min(6.6, Math.max(5.0, d - 1.6));
    const cx = x + w/2, cz = z + d/2;

    this.furnitureGroup.add(
      this.box(bw,.42,bd,wood,cx,.38,cz),
      this.box(bw-.18,.34,bd-.18,linen,cx,.74,cz),
      this.box(bw-.28,.16,bd*.60,duvet,cx,.98,cz+bd*.10),
      this.box(bw,1.55,.20,wood,cx,1.24,cz-bd/2)
    );

    // pillows
    const pillow = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 1 });
    this.furnitureGroup.add(
      this.box(bw*.34,.16,.85,pillow,cx-bw*.20,1.06,cz-bd*.26),
      this.box(bw*.34,.16,.85,pillow,cx+bw*.20,1.06,cz-bd*.26)
    );

    // side tables
    const sideMat = new THREE.MeshStandardMaterial({ color: 0x8b6347, roughness: .8 });
    this.furnitureGroup.add(
      this.box(.78,.55,.78,sideMat,cx-bw/2-.55,.42,cz-bd*.28),
      this.box(.78,.55,.78,sideMat,cx+bw/2+.55,.42,cz-bd*.28)
    );

    // wardrobe
    const ward = this.box(Math.min(3.6,w*.30),2.35,.70,
      new THREE.MeshStandardMaterial({ color: 0x9b765a, roughness:.82 }),
      x+.75,1.18,z+d-.72);
    this.furnitureGroup.add(ward);
  }

  private furnishDining(room: any): void {
    const x = +room.x, z = +room.y, w = +room.width, d = +room.height;
    const cx = x+w/2, cz = z+d/2;

    const wood = new THREE.MeshStandardMaterial({ color: 0x805638, roughness:.76 });
    this.furnitureGroup.add(this.box(Math.min(5.2,w-1.2),.22,2.5,wood,cx,.88,cz));

    const pts = [
      [cx-1.8,cz-1.8,0],[cx+1.8,cz-1.8,0],[cx-1.8,cz+1.8,Math.PI],[cx+1.8,cz+1.8,Math.PI]
    ];

    for (const [px,pz,rot] of pts) {
      const g = new THREE.Group();
      const seat = this.box(.82,.18,.82,wood,0,.55,0);
      const back = this.box(.82,1.0,.12,wood,0,1.02,-.35);
      g.add(seat,back);
      g.position.set(px,0,pz);
      g.rotation.y = rot;
      this.furnitureGroup.add(g);
    }
  }

  private furnishKitchen(room: any): void {
    const x = +room.x, z = +room.y, w = +room.width, d = +room.height;

    const cabinet = new THREE.MeshStandardMaterial({ color: 0xe5e1da, roughness:.78 });
    const top = new THREE.MeshStandardMaterial({ color: 0x44484c, roughness:.45 });
    const dark = new THREE.MeshStandardMaterial({ color: 0x2e3135, roughness:.35 });

    // L counter
    this.furnitureGroup.add(
      this.box(Math.max(3,w-1.0),.90,1.2,cabinet,x+w/2,.48,z+.78),
      this.box(Math.max(3,w-.9),.10,1.28,top,x+w/2,.98,z+.78),
      this.box(1.2,.90,Math.max(3,d*.56),cabinet,x+.78,.48,z+d*.53),
      this.box(1.28,.10,Math.max(3,d*.56),top,x+.78,.98,z+d*.53)
    );

    // upper cabinets
    for (let i=0;i<3;i++) {
      const uw = Math.max(1.2,(w-2.0)/3);
      this.furnitureGroup.add(
        this.box(uw-.08,.90,.38,cabinet,x+1.1+uw*i,.2+1.95,z+.28)
      );
    }

    // hob
    this.furnitureGroup.add(
      this.box(1.6,.06,.9,dark,x+w*.62,1.04,z+.78)
    );

    // island
    const iw = Math.min(4.2,w*.34);
    this.furnitureGroup.add(
      this.box(iw,.90,1.7,cabinet,x+w*.65,.47,z+d*.64),
      this.box(iw+.08,.09,1.78,top,x+w*.65,.97,z+d*.64)
    );
  }

  private furnishBathroom(room: any): void {
    const x=+room.x,z=+room.y,w=+room.width,d=+room.height;
    const ceramic = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness:.36 });
    const chrome = new THREE.MeshStandardMaterial({ color: 0xbfc4c8, roughness:.22, metalness:.65 });

    const toilet = new THREE.Mesh(new THREE.CylinderGeometry(.48,.60,.55,24),ceramic);
    toilet.position.set(x+1.0,.30,z+1.2);

    const tank = this.box(.78,.82,.35,ceramic,x+1.0,.95,z+.75);
    const sink = this.box(1.15,.18,.72,ceramic,x+w-1.0,.95,z+1.0);

    const tap = new THREE.Mesh(new THREE.CylinderGeometry(.05,.05,.38,12),chrome);
    tap.rotation.z = Math.PI/2;
    tap.position.set(x+w-1.0,1.15,z+1.0);

    const showerGlass = this.box(
      Math.min(2.2,w*.35),2.0,.05,
      new THREE.MeshPhysicalMaterial({
        color: 0xbde7ff, transparent:true, opacity:.25, transmission:.6, roughness:.05
      }),
      x+w-1.2,1.0,z+d-1.0
    );

    this.furnitureGroup.add(toilet,tank,sink,tap,showerGlass);
  }

  private buildDecor(): void {
    const lw = Number(this.land?.width ?? 40);
    const ll = Number(this.land?.length ?? 60);

    // porch deck
    const deckMat = new THREE.MeshStandardMaterial({ color: 0x9a6a47, roughness:.88 });
    const deck = this.box(Math.min(11,lw*.35),.12,3.0,deckMat,lw*.32,.06,-1.3);
    this.decorGroup.add(deck);

    // path
    const stone = new THREE.MeshStandardMaterial({ color: 0xc8c5be, roughness:.95 });
    this.decorGroup.add(this.box(3.2,.05,8.0,stone,lw*.32,.03,-5.2));

    // small lawns
    const grass = new THREE.MeshStandardMaterial({ color: 0x8dbb70, roughness:1 });
    this.decorGroup.add(
      this.box(Math.max(5,lw*.18),.04,6,grass,lw*.09,.02,-4.1),
      this.box(Math.max(5,lw*.18),.04,6,grass,lw*.55,.02,-4.1)
    );

    // plants
    for (const [px,pz] of [[lw*.08,-3.8],[lw*.82,-3.8],[lw*.88,ll*.18]]) {
      this.addPlant(px,pz);
    }

    // railing at front deck
    const metal = new THREE.MeshStandardMaterial({ color: 0x2b2f32, roughness:.55, metalness:.35 });
    const rx = lw*.32;
    const railW = Math.min(11,lw*.35);

    this.decorGroup.add(this.box(railW,.08,.08,metal,rx,1.0,-2.72));
    for (let i=0;i<7;i++) {
      const px = rx - railW/2 + i*(railW/6);
      this.decorGroup.add(this.box(.07,1.0,.07,metal,px,.5,-2.72));
    }
  }

  private addPlant(x:number,z:number): void {
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x765138, roughness:1 });
    const leafMat = new THREE.MeshStandardMaterial({ color: 0x4f7f42, roughness:1 });
    const potMat = new THREE.MeshStandardMaterial({ color: 0xa66d45, roughness:.9 });

    const pot = new THREE.Mesh(new THREE.CylinderGeometry(.36,.48,.45,16),potMat);
    pot.position.set(x,.24,z);

    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(.07,.08,.85,10),trunkMat);
    trunk.position.set(x,.85,z);

    const crown = new THREE.Mesh(new THREE.SphereGeometry(.55,16,12),leafMat);
    crown.position.set(x,1.45,z);

    this.decorGroup.add(pot,trunk,crown);
  }

  private buildRoof(): void {
    const lw = Number(this.land?.width ?? 40);
    const ll = Number(this.land?.length ?? 60);

    const roofY = 3.55;
    const over = .7;
    const rise = Math.max(2.0,lw*.10);
    const roofMat = new THREE.MeshStandardMaterial({ color: 0x9f4f3f, roughness:.86, side:THREE.DoubleSide });
    const trimMat = new THREE.MeshStandardMaterial({ color: 0xf0ede7, roughness:.82 });

    const leftShape = new THREE.Shape();
    leftShape.moveTo(-over,0);
    leftShape.lineTo(lw/2,rise);
    leftShape.lineTo(lw/2,rise+.14);
    leftShape.lineTo(-over,.14);
    leftShape.closePath();

    const leftGeo = new THREE.ExtrudeGeometry(leftShape,{depth:ll+over*2,bevelEnabled:false});
    const left = new THREE.Mesh(leftGeo,roofMat);
    left.position.set(0,roofY,-over);
    left.castShadow = true;

    const rightShape = new THREE.Shape();
    rightShape.moveTo(0,rise);
    rightShape.lineTo(lw/2+over,0);
    rightShape.lineTo(lw/2+over,.14);
    rightShape.lineTo(0,rise+.14);
    rightShape.closePath();

    const rightGeo = new THREE.ExtrudeGeometry(rightShape,{depth:ll+over*2,bevelEnabled:false});
    const right = new THREE.Mesh(rightGeo,roofMat);
    right.position.set(lw/2,roofY,-over);
    right.castShadow = true;

    const fascia1 = this.box(lw+over*2,.18,.15,trimMat,lw/2,roofY+.07,-over);
    const fascia2 = fascia1.clone();
    fascia2.position.z = ll+over;

    this.roofGroup.add(left,right,fascia1,fascia2);
  }

  private addDoorObjects(): void {
    const frameMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness:.82 });
    const panelMat = new THREE.MeshStandardMaterial({ color: 0xd8d3cb, roughness:.80 });

    for (const door of this.doors) {
      const x=+door.x,z=+door.y,s=+(door.width??3);
      const h=2.30,t=.08;

      if (door.orientation === 'vertical') {
        this.houseGroup.add(
          this.box(t,h,t,frameMat,x,h/2,z),
          this.box(t,h,t,frameMat,x,h/2,z+s),
          this.box(t,t,s,frameMat,x,h,z+s/2),
          this.box(.05,h*.94,s*.90,panelMat,x+.03,h*.47,z+s/2)
        );
      } else {
        this.houseGroup.add(
          this.box(t,h,t,frameMat,x,h/2,z),
          this.box(t,h,t,frameMat,x+s,h/2,z),
          this.box(s,t,t,frameMat,x+s/2,h,z),
          this.box(s*.90,h*.94,.05,panelMat,x+s/2,h*.47,z+.03)
        );
      }
    }
  }

  private addWindowObjects(): void {
    const frameMat = new THREE.MeshStandardMaterial({ color: 0x38434c, roughness:.35, metalness:.15 });
    const glassMat = new THREE.MeshPhysicalMaterial({
      color: 0x9bd2f1, transparent:true, opacity:.33, transmission:.45, roughness:.06
    });

    for (const win of this.windows) {
      const x=+win.x,z=+win.y,s=+(win.width??4);
      const bottom=1.0,h=1.28;

      if (win.orientation === 'vertical') {
        this.houseGroup.add(
          this.box(.04,h,s,glassMat,x,bottom+h/2,z+s/2),
          this.box(.08,h+.10,.08,frameMat,x,bottom+h/2,z),
          this.box(.08,h+.10,.08,frameMat,x,bottom+h/2,z+s),
          this.box(.08,h+.10,.06,frameMat,x,bottom+h/2,z+s/2),
          this.box(.08,.08,s,frameMat,x,bottom,z+s/2),
          this.box(.08,.08,s,frameMat,x,bottom+h,z+s/2)
        );
      } else {
        this.houseGroup.add(
          this.box(s,h,.04,glassMat,x+s/2,bottom+h/2,z),
          this.box(.08,h+.10,.08,frameMat,x,bottom+h/2,z),
          this.box(.08,h+.10,.08,frameMat,x+s,bottom+h/2,z),
          this.box(.06,h+.10,.08,frameMat,x+s/2,bottom+h/2,z),
          this.box(s,.08,.08,frameMat,x+s/2,bottom,z),
          this.box(s,.08,.08,frameMat,x+s/2,bottom+h,z)
        );
      }
    }
  }

  private buildLabels(): void {
    for (const room of this.rooms) {
      const canvas = document.createElement('canvas');
      canvas.width = 512; canvas.height = 128;
      const ctx = canvas.getContext('2d');
      if (!ctx) continue;

      ctx.fillStyle = 'rgba(255,255,255,.90)';
      ctx.fillRect(8,8,496,112);
      ctx.strokeStyle = '#c9ced6';
      ctx.strokeRect(8,8,496,112);
      ctx.fillStyle = '#23314f';
      ctx.font = 'bold 32px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(String(room.name),256,64);

      const tex = new THREE.CanvasTexture(canvas);
      tex.colorSpace = THREE.SRGBColorSpace;
      const sprite = new THREE.Sprite(new THREE.SpriteMaterial({map:tex,transparent:true,depthTest:false}));
      sprite.scale.set(4.6,1.15,1);
      sprite.position.set(+room.x + +room.width/2, 2.65, +room.y + +room.height/2);
      this.labelGroup.add(sprite);
    }
  }

  private box(
    w:number,h:number,d:number,
    mat:THREE.Material,
    x:number,y:number,z:number
  ): THREE.Mesh {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat);
    m.position.set(x,y,z);
    m.castShadow = true;
    m.receiveShadow = true;
    return m;
  }

  private animate = (): void => {
    if (!this.renderer || !this.scene || !this.camera) return;
    this.animationId = requestAnimationFrame(this.animate);
    this.controls?.update();
    this.renderer.render(this.scene,this.camera);
  };

  private disposeThree(): void {
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
      this.animationId = 0;
    }

    this.resizeObserver?.disconnect();
    this.resizeObserver = undefined;

    this.controls?.dispose();
    this.controls = undefined;

    if (this.scene) {
      this.scene.traverse(obj => {
        const mesh = obj as THREE.Mesh;
        mesh.geometry?.dispose();

        const material = mesh.material as THREE.Material | THREE.Material[] | undefined;
        if (Array.isArray(material)) material.forEach(m=>m.dispose());
        else material?.dispose();
      });
    }

    this.renderer?.dispose();

    const container = this.threeContainer?.nativeElement;
    if (container) container.innerHTML = '';

    this.renderer = undefined;
    this.scene = undefined;
    this.camera = undefined;

    this.houseGroup = new THREE.Group();
    this.roofGroup = new THREE.Group();
    this.furnitureGroup = new THREE.Group();
    this.decorGroup = new THREE.Group();
    this.labelGroup = new THREE.Group();
    this.lightGroup = new THREE.Group();
  }

  // 2D fallback
  private buildSvg(
    rooms:any[],
    doors:any[],
    windows:any[],
    name:string,
    score:number|null
  ): string {
    const lw=Number(this.land?.width??40), ll=Number(this.land?.length??60);
    const W=900,H=760,L=70,T=100,R=150,B=70;
    const s=Math.min((W-L-R)/lw,(H-T-B)/ll);

    const pxX=(x:number)=>L+x*s;
    const pxY=(y:number)=>T+y*s;

    let svg=`<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
    <rect width="100%" height="100%" fill="white"/>
    <text x="${W/2}" y="32" text-anchor="middle" font-size="24" font-family="Arial" font-weight="bold">BuildMind - AI Generated 2D Floor Plan</text>
    <text x="${L}" y="78" font-size="14" font-family="Arial" font-weight="bold" fill="#3157ff">${name}</text>
    ${score!==null?`<text x="${L+180}" y="78" font-size="13" font-family="Arial" font-weight="bold" fill="#059669">AI Score: ${score}</text>`:''}
    <rect x="${L}" y="${T}" width="${lw*s}" height="${ll*s}" fill="white" stroke="#111" stroke-width="5"/>`;

    for(const r of rooms){
      const x=pxX(r.x),y=pxY(r.y),w=r.width*s,h=r.height*s;
      svg+=`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="#f6f2ea" stroke="#20252b" stroke-width="2"/>
      <text x="${x+w/2}" y="${y+h/2}" text-anchor="middle" font-family="Arial" font-size="10" font-weight="bold">${r.name}</text>`;
    }

    svg+=`</svg>`;
    return svg;
  }
}
