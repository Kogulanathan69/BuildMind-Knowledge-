# BuildMind: Live 2D → 3D Upgrade

This package contains replacement files for an **existing Angular 22 project**.

## Setup

1. In your existing Angular project folder, run:

   ```powershell
   npm install konva three
   npm install -D @types/three
   ```

2. Copy `src/app/app.ts`, `src/app/app.html`, `src/app/app.css`, and `src/styles.css` from this package into your project.
3. Start your app:

   ```powershell
   npx ng serve --open
   ```

## Features

- Live 3D rebuilds during room/furniture dragging and after editing.
- Up to three levels: ground, first and second floor.
- Draw snap-to-grid rectangular rooms and move them.
- Rename rooms, change exact width/depth via the Properties panel.
- Doors and windows are placed on the nearest room wall and show simplified 3D openings.
- Place and drag simplified bed, sofa and table models.
- Show/hide a simplified flat or pitched roof.
- JSON export/import.
- Orbit/pan/zoom 3D view; show active level only or all levels.

## Limitations

This is a learning prototype, **not** architectural or construction-ready software.
- Rooms are independent rectangles. Adjacent rooms have overlapping walls and are not automatically merged.
- Doors are simplified panels; no hinges, swing arcs or collision rules.
- The pitched roof follows the bounding box of the highest visible floor (not each roof plane).
- Floor slabs can overlap when rectangles overlap.
- Furniture models are box placeholders, not realistic models.
- No undo/redo, collision validation, stairs, foundation, plumbing, electrical, structural analysis or reliable BOQ.
- Live scene regeneration suits small plans; for large designs, use incremental geometry updates and throttling.
- Imported JSON uses basic geometry validation and is not an untrusted-document production parser.

## Usage tips

1. Choose Draw Room. Drag on the canvas to create a rectangular room.
2. Select room, rename in Properties and set its width/depth in metres.
3. Choose Place Door or Place Window and click a wall edge of the room.
4. Choose a furniture tool and click a location on the plan.
5. Add First floor / Second floor using the floor dropdown. 2D edits affect active floor.
6. Toggle roof and Show all levels; 3D updates without a Generate button.
7. Save JSON and reimport it later.

Note: The canvas is scrollable and fixed at 1000×700 px, at 50 px per metre.
