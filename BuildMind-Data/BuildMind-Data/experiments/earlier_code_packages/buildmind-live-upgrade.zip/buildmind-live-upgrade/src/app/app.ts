import { Component, AfterViewInit, OnDestroy } from '@angular/core';
import Konva from 'konva';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

type Tool = 'select' | 'room' | 'door' | 'window' | 'bed' | 'sofa' | 'table';
type Side = 'top' | 'right' | 'bottom' | 'left';
type OpeningKind = 'door' | 'window';
type FurnitureKind = 'bed' | 'sofa' | 'table';

interface Level { id: number; name: string; }
interface Room { id: number; levelId: number; name: string; x: number; y: number; width: number; height: number; }
interface Opening { id: number; roomId: number; kind: OpeningKind; side: Side; offset: number; width: number; }
interface Furniture { id: number; levelId: number; kind: FurnitureKind; x: number; y: number; width: number; depth: number; }
interface PlanFile { version: number; levels: Level[]; rooms: Room[]; openings: Opening[]; furniture: Furniture[]; roofStyle: 'flat' | 'gable'; showRoof: boolean; }

@Component({ selector: 'app-root', standalone: true, templateUrl: './app.html', styleUrl: './app.css' })
export class App implements AfterViewInit, OnDestroy {
  readonly pxPerMeter = 50;
  readonly canvasWidth = 1000;
  readonly canvasHeight = 700;
  readonly levelHeight = 3.1;
  readonly wallThickness = 0.16;
  readonly gridSize = 25;

  tool: Tool = 'room';
  levels: Level[] = [{ id: 1, name: 'Ground floor' }];
  activeLevelId = 1;
  rooms: Room[] = [];
  openings: Opening[] = [];
  furniture: Furniture[] = [];
  selectedRoomId: number | null = null;
  roofStyle: 'flat' | 'gable' = 'flat';
  showRoof = false;
  showAllLevels = true;
  status = 'Draw a room: choose Draw Room, then drag on the grid.';

  private nextId = 2;
  private stage!: Konva.Stage;
  private gridLayer!: Konva.Layer;
  private roomLayer!: Konva.Layer;
  private previewLayer!: Konva.Layer;
  private start: { x: number; y: number } | null = null;
  private draftRoom: Room | null = null;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private orbit!: OrbitControls;
  private model = new THREE.Group();
  private resizeObserver?: ResizeObserver;
  private pendingFrame = 0;
  private disposed = false;

  get selectedRoom(): Room | undefined { return this.rooms.find(r => r.id === this.selectedRoomId); }
  get activeLevel(): Level { return this.levels.find(l => l.id === this.activeLevelId)!; }

  ngAfterViewInit(): void { this.initKonva(); this.initThree(); this.queue3D(); }

  private snap(n: number): number { return Math.round(n / this.gridSize) * this.gridSize; }
  private pointer(): { x: number; y: number } | null {
    const p = this.stage.getPointerPosition();
    return p ? { x: Math.max(0, Math.min(this.canvasWidth, this.snap(p.x))), y: Math.max(0, Math.min(this.canvasHeight, this.snap(p.y))) } : null;
  }

  private initKonva(): void {
    this.stage = new Konva.Stage({ container: 'konva-canvas', width: this.canvasWidth, height: this.canvasHeight });
    this.gridLayer = new Konva.Layer({ listening: false });
    this.roomLayer = new Konva.Layer();
    this.previewLayer = new Konva.Layer({ listening: false });
    this.stage.add(this.gridLayer, this.roomLayer, this.previewLayer);
    for (let x = 0; x <= this.canvasWidth; x += this.gridSize) this.gridLayer.add(new Konva.Line({ points: [x, 0, x, this.canvasHeight], stroke: x % 100 === 0 ? '#d4dfed' : '#eaf0f7', strokeWidth: 1 }));
    for (let y = 0; y <= this.canvasHeight; y += this.gridSize) this.gridLayer.add(new Konva.Line({ points: [0, y, this.canvasWidth, y], stroke: y % 100 === 0 ? '#d4dfed' : '#eaf0f7', strokeWidth: 1 }));
    this.gridLayer.draw();

    this.stage.on('mousedown touchstart', () => {
      if (this.tool !== 'room') return;
      this.start = this.pointer();
    });
    this.stage.on('mousemove touchmove', () => {
      if (!this.start || this.tool !== 'room') return;
      const end = this.pointer(); if (!end) return;
      this.previewLayer.destroyChildren();
      this.previewLayer.add(new Konva.Rect({ x: Math.min(this.start.x, end.x), y: Math.min(this.start.y, end.y), width: Math.abs(end.x - this.start.x), height: Math.abs(end.y - this.start.y), stroke: '#2563eb', strokeWidth: 2, fill: '#bfdbfe55', dash: [6, 5] }));
      this.previewLayer.batchDraw();
      const w = Math.abs(end.x - this.start.x), h = Math.abs(end.y - this.start.y);
      this.draftRoom = w >= 25 && h >= 25 ? { id: -1, levelId: this.activeLevelId, name: 'New room', x: Math.min(this.start.x, end.x), y: Math.min(this.start.y, end.y), width: w, height: h } : null;
      this.queue3D();
    });
    this.stage.on('mouseup touchend', () => {
      if (!this.start || this.tool !== 'room') return;
      const end = this.pointer(); const start = this.start; this.start = null; this.draftRoom = null;
      this.previewLayer.destroyChildren(); this.previewLayer.batchDraw();
      if (!end) { this.queue3D(); return; }
      const width = Math.abs(end.x - start.x), height = Math.abs(end.y - start.y);
      if (width < 50 || height < 50) return;
      const r: Room = { id: this.nextId++, levelId: this.activeLevelId, name: 'Room ' + (this.rooms.length + 1), x: Math.min(start.x, end.x), y: Math.min(start.y, end.y), width, height };
      this.rooms.push(r); this.selectedRoomId = r.id; this.tool = 'select';
      this.status = 'Room created. Rename it in the properties panel. Drag it to move.';
      this.draw2D(); this.queue3D();
    });
    this.stage.on('click tap', event => {
      if (event.target === this.stage && this.tool === 'select') { this.selectedRoomId = null; this.draw2D(); }
      if (this.tool === 'bed' || this.tool === 'sofa' || this.tool === 'table') {
        const p = this.pointer(); if (!p) return;
        const kind = this.tool;
        const sizes = { bed: [100, 90], sofa: [110, 50], table: [65, 65] };
        const [width, depth] = sizes[kind];
        this.furniture.push({ id: this.nextId++, levelId: this.activeLevelId, kind, x: p.x, y: p.y, width, depth });
        this.tool = 'select'; this.draw2D(); this.queue3D();
      }
    });
    this.draw2D();
  }

  setTool(tool: Tool): void { this.tool = tool; this.start = null; this.draftRoom = null; this.previewLayer.destroyChildren(); this.previewLayer.batchDraw(); this.draw2D(); this.queue3D(); }
  setLevel(value: string): void { this.activeLevelId = Number(value); this.selectedRoomId = null; this.draw2D(); this.queue3D(); }
  addLevel(): void {
    if (this.levels.length >= 3) { this.status = 'Prototype limit: ground + two upper floors.'; return; }
    const id = this.nextId++; this.levels.push({ id, name: this.levels.length === 1 ? 'First floor' : 'Second floor' });
    this.activeLevelId = id; this.selectedRoomId = null; this.draw2D(); this.queue3D();
  }
  selectRoom(r: Room): void { this.selectedRoomId = r.id; this.draw2D(); }
  updateRoom(field: 'name' | 'width' | 'height', value: string): void {
    const r = this.selectedRoom; if (!r) return;
    if (field === 'name') r.name = value.slice(0, 50) || 'Room';
    else {
      const metres = Number(value);
      if (!Number.isFinite(metres) || metres < 1 || metres > 20) return;
      r[field] = this.snap(metres * this.pxPerMeter);
      this.fitOpenings(r);
    }
    this.draw2D(); this.queue3D();
  }
  deleteSelected(): void {
    if (this.selectedRoomId === null) return;
    const id = this.selectedRoomId;
    this.rooms = this.rooms.filter(r => r.id !== id);
    this.openings = this.openings.filter(o => o.roomId !== id);
    this.selectedRoomId = null; this.draw2D(); this.queue3D();
  }

  private fitOpenings(r: Room): void {
    for (const o of this.openings.filter(o => o.roomId === r.id)) {
      const length = (o.side === 'top' || o.side === 'bottom') ? r.width : r.height;
      o.offset = Math.max(o.width / 2, Math.min(length - o.width / 2, o.offset));
    }
  }

  private addOpening(r: Room, p: { x: number; y: number }, kind: OpeningKind): void {
    const localX = p.x - r.x, localY = p.y - r.y;
    const edges: { side: Side; distance: number; offset: number; length: number }[] = [
      { side: 'top', distance: Math.abs(localY), offset: localX, length: r.width },
      { side: 'bottom', distance: Math.abs(localY - r.height), offset: localX, length: r.width },
      { side: 'left', distance: Math.abs(localX), offset: localY, length: r.height },
      { side: 'right', distance: Math.abs(localX - r.width), offset: localY, length: r.height }
    ];
    edges.sort((a, b) => a.distance - b.distance);
    const closest = edges[0];
    const width = kind === 'door' ? 45 : 60;
    if (closest.length < width + 20) { this.status = 'Wall is too short for this opening.'; return; }
    const offset = Math.max(width / 2 + 10, Math.min(closest.length - width / 2 - 10, closest.offset));
    // Avoid overlapping openings on the same wall.
    if (this.openings.some(o => o.roomId === r.id && o.side === closest.side && Math.abs(o.offset - offset) < (o.width + width) / 2 + 5)) {
      this.status = 'Opening overlaps another opening. Try another position.'; return;
    }
    this.openings.push({ id: this.nextId++, roomId: r.id, kind, side: closest.side, offset, width });
    this.status = kind === 'door' ? 'Door inserted.' : 'Window inserted.';
    this.draw2D(); this.queue3D();
  }

  private draw2D(): void {
    if (!this.roomLayer) return;
    this.roomLayer.destroyChildren();
    for (const r of this.rooms.filter(r => r.levelId === this.activeLevelId)) {
      const group = new Konva.Group({ x: r.x, y: r.y, draggable: this.tool === 'select' });
      const selected = r.id === this.selectedRoomId;
      group.add(new Konva.Rect({ width: r.width, height: r.height, fill: selected ? '#dbeafe' : '#f0f7ff', stroke: selected ? '#2563eb' : '#334155', strokeWidth: selected ? 4 : 3 }));
      group.add(new Konva.Text({ x: 8, y: r.height / 2 - 17, width: Math.max(10, r.width - 16), text: r.name, align: 'center', fontSize: 15, fontStyle: 'bold', fill: '#1d4ed8', listening: false }));
      group.add(new Konva.Text({ x: 5, y: 8, width: Math.max(10, r.width - 10), text: (r.width / this.pxPerMeter).toFixed(1) + 'm × ' + (r.height / this.pxPerMeter).toFixed(1) + 'm', align: 'center', fontSize: 12, fill: '#475569', listening: false }));
      for (const o of this.openings.filter(o => o.roomId === r.id)) {
        const horizontal = o.side === 'top' || o.side === 'bottom';
        const ox = horizontal ? o.offset : o.side === 'left' ? 0 : r.width;
        const oy = horizontal ? (o.side === 'top' ? 0 : r.height) : o.offset;
        group.add(new Konva.Line({ points: horizontal ? [ox - o.width / 2, oy, ox + o.width / 2, oy] : [ox, oy - o.width / 2, ox, oy + o.width / 2], stroke: '#ffffff', strokeWidth: 8, listening: false }));
        group.add(new Konva.Line({ points: horizontal ? [ox - o.width / 2, oy, ox + o.width / 2, oy] : [ox, oy - o.width / 2, ox, oy + o.width / 2], stroke: o.kind === 'door' ? '#16a34a' : '#0284c7', strokeWidth: 4, listening: false }));
      }
      group.on('click tap', e => {
        e.cancelBubble = true;
        if (this.tool === 'door' || this.tool === 'window') {
          const pos = this.pointer(); if (pos) this.addOpening(r, pos, this.tool);
        } else if (this.tool === 'select') this.selectRoom(r);
      });
      group.on('dragmove', () => {
        r.x = this.snap(group.x()); r.y = this.snap(group.y());
        group.position({ x: r.x, y: r.y }); this.queue3D();
      });
      group.on('dragend', () => { this.draw2D(); this.queue3D(); });
      this.roomLayer.add(group);
    }
    for (const f of this.furniture.filter(f => f.levelId === this.activeLevelId)) {
      const group = new Konva.Group({ x: f.x, y: f.y, draggable: this.tool === 'select' });
      group.add(new Konva.Rect({ width: f.width, height: f.depth, fill: f.kind === 'bed' ? '#c4b5fd' : f.kind === 'sofa' ? '#facc15' : '#fdba74', cornerRadius: 5, stroke: '#64748b', strokeWidth: 2 }));
      group.add(new Konva.Text({ width: f.width, y: f.depth / 2 - 8, align: 'center', text: f.kind.toUpperCase(), fontSize: 13, fill: '#334155', listening: false }));
      group.on('dragmove', () => { f.x = this.snap(group.x()); f.y = this.snap(group.y()); group.position({ x: f.x, y: f.y }); this.queue3D(); });
      group.on('dblclick dbltap', () => { this.furniture = this.furniture.filter(item => item.id !== f.id); this.draw2D(); this.queue3D(); });
      this.roomLayer.add(group);
    }
    this.roomLayer.batchDraw();
  }

  private initThree(): void {
    const host = document.getElementById('three-canvas')!;
    this.scene = new THREE.Scene(); this.scene.background = new THREE.Color('#e9f0f8');
    this.camera = new THREE.PerspectiveCamera(45, 1, 0.1, 600);
    this.camera.position.set(13, 15, 16);
    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    host.appendChild(this.renderer.domElement);
    this.orbit = new OrbitControls(this.camera, this.renderer.domElement);
    this.orbit.enableDamping = true; this.orbit.target.set(0, 1.5, 0);
    this.scene.add(new THREE.AmbientLight('#ffffff', 2.0));
    const sun = new THREE.DirectionalLight('#ffffff', 2.5); sun.position.set(10, 18, 12); this.scene.add(sun);
    const ground = new THREE.GridHelper(70, 70, '#9ca3af', '#d5deea'); ground.position.y = -0.1; this.scene.add(ground);
    this.scene.add(this.model);
    const resize = () => {
      const width = host.clientWidth, height = host.clientHeight;
      if (!width || !height) return;
      this.renderer.setSize(width, height, false);
      this.camera.aspect = width / height; this.camera.updateProjectionMatrix();
    };
    this.resizeObserver = new ResizeObserver(resize); this.resizeObserver.observe(host); resize();
    this.renderer.setAnimationLoop(() => { this.orbit.update(); this.renderer.render(this.scene, this.camera); });
  }

  private box(width: number, height: number, depth: number, x: number, y: number, z: number, color: string): void {
    if (width <= 0 || height <= 0 || depth <= 0) return;
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(width, height, depth), new THREE.MeshStandardMaterial({ color, roughness: 0.8 }));
    mesh.position.set(x, y, z); this.model.add(mesh);
  }
  private queue3D(): void {
    if (this.pendingFrame || this.disposed || !this.renderer) return;
    this.pendingFrame = requestAnimationFrame(() => { this.pendingFrame = 0; this.build3D(); });
  }
  private clear3D(): void {
    this.model.traverse(obj => {
      if (!(obj instanceof THREE.Mesh)) return;
      obj.geometry.dispose();
      const materials = Array.isArray(obj.material) ? obj.material : [obj.material];
      materials.forEach(m => m.dispose());
    });
    this.model.clear();
  }
  private build3D(): void {
    this.clear3D();
    const activeRooms = this.rooms.filter(r => this.showAllLevels || r.levelId === this.activeLevelId);
    if (this.draftRoom) activeRooms.push(this.draftRoom);
    if (activeRooms.length === 0) return;
    const minX = Math.min(...activeRooms.map(r => r.x)), maxX = Math.max(...activeRooms.map(r => r.x + r.width));
    const minY = Math.min(...activeRooms.map(r => r.y)), maxY = Math.max(...activeRooms.map(r => r.y + r.height));
    const cx = (minX + maxX) / 2, cy = (minY + maxY) / 2;
    const scale = this.pxPerMeter;
    const highestVisibleLevel = Math.max(...activeRooms.map(r => this.levels.findIndex(l => l.id === r.levelId)));
    for (const r of activeRooms) {
      const levelIndex = this.levels.findIndex(l => l.id === r.levelId);
      const base = levelIndex * this.levelHeight;
      const w = r.width / scale, d = r.height / scale;
      const x = (r.x + r.width / 2 - cx) / scale, z = (r.y + r.height / 2 - cy) / scale;
      this.box(w, 0.14, d, x, base + 0.07, z, '#dbeafe');
      for (const side of ['top', 'bottom', 'left', 'right'] as Side[]) {
        const horizontal = side === 'top' || side === 'bottom';
        const wallLength = horizontal ? w : d;
        const wallX = horizontal ? x : x + (side === 'left' ? -w / 2 : w / 2);
        const wallZ = horizontal ? z + (side === 'top' ? -d / 2 : d / 2) : z;
        const openings = this.openings.filter(o => o.roomId === r.id && o.side === side).sort((a, b) => a.offset - b.offset);
        let cursor = 0;
        const segment = (from: number, to: number, bottom: number, top: number) => {
          if (to - from < 0.002 || top - bottom < 0.002) return;
          const center = (from + to) / 2 - wallLength / 2;
          this.box(horizontal ? to - from : this.wallThickness, top - bottom, horizontal ? this.wallThickness : to - from,
            wallX + (horizontal ? center : 0), base + (top + bottom) / 2, wallZ + (horizontal ? 0 : center), '#f8fafc');
        };
        for (const o of openings) {
          const start = Math.max(cursor, (o.offset - o.width / 2) / scale);
          const end = Math.min(wallLength, (o.offset + o.width / 2) / scale);
          if (end <= start) continue;
          segment(cursor, start, 0, 2.9);
          if (o.kind === 'door') {
            segment(start, end, 2.2, 2.9); // lintel over door
            // door panel (thin colored translucent-looking object)
            const mid = (start + end) / 2 - wallLength / 2;
            this.box(horizontal ? end - start : 0.035, 2.08, horizontal ? 0.035 : end - start,
              wallX + (horizontal ? mid : 0), base + 1.04, wallZ + (horizontal ? 0 : mid), '#b48b67');
          } else {
            segment(start, end, 0, 0.9); // sill
            segment(start, end, 2.1, 2.9); // header
            const mid = (start + end) / 2 - wallLength / 2;
            this.box(horizontal ? end - start : 0.035, 1.2, horizontal ? 0.035 : end - start,
              wallX + (horizontal ? mid : 0), base + 1.5, wallZ + (horizontal ? 0 : mid), '#8ad4f2');
          }
          cursor = end;
        }
        segment(cursor, wallLength, 0, 2.9);
      }
    }
    for (const f of this.furniture.filter(f => this.showAllLevels || f.levelId === this.activeLevelId)) {
      const levelIndex = this.levels.findIndex(l => l.id === f.levelId);
      const base = levelIndex * this.levelHeight;
      const h = f.kind === 'bed' ? 0.5 : f.kind === 'sofa' ? 0.75 : 0.8;
      this.box(f.width / scale, h, f.depth / scale,
        (f.x + f.width / 2 - cx) / scale, base + 0.14 + h / 2,
        (f.y + f.depth / 2 - cy) / scale, f.kind === 'bed' ? '#a78bfa' : f.kind === 'sofa' ? '#fbbf24' : '#fb923c');
    }
    if (this.showRoof) {
      const topRooms = activeRooms.filter(r => this.levels.findIndex(l => l.id === r.levelId) === highestVisibleLevel);
      const rx1 = Math.min(...topRooms.map(r => r.x)), rx2 = Math.max(...topRooms.map(r => r.x + r.width));
      const ry1 = Math.min(...topRooms.map(r => r.y)), ry2 = Math.max(...topRooms.map(r => r.y + r.height));
      const rw = (rx2 - rx1) / scale + 0.4, rd = (ry2 - ry1) / scale + 0.4;
      const rx = ((rx1 + rx2) / 2 - cx) / scale, rz = ((ry1 + ry2) / 2 - cy) / scale;
      const roofY = (highestVisibleLevel + 1) * this.levelHeight;
      if (this.roofStyle === 'flat') this.box(rw, 0.18, rd, rx, roofY, rz, '#64748b');
      else {
        const rise = Math.max(0.7, rw * 0.23);
        const slopeLength = Math.hypot(rw / 2, rise);
        const angle = Math.atan2(rise, rw / 2);
        for (const sign of [-1, 1]) {
          const roof = new THREE.Mesh(new THREE.BoxGeometry(slopeLength, 0.14, rd), new THREE.MeshStandardMaterial({ color: '#9f4450', roughness: 0.85 }));
          roof.position.set(rx + sign * rw / 4, roofY + rise / 2, rz);
          roof.rotation.z = sign === -1 ? angle : -angle;
          this.model.add(roof);
        }
      }
    }
  }

  setRoofStyle(value: string): void { this.roofStyle = value === 'gable' ? 'gable' : 'flat'; this.queue3D(); }
  toggleRoof(value: boolean): void { this.showRoof = value; this.queue3D(); }
  toggleAllLevels(value: boolean): void { this.showAllLevels = value; this.queue3D(); }
  resetCamera(): void { this.camera.position.set(13, 15, 16); this.orbit.target.set(0, 2, 0); this.orbit.update(); }
  removeOpening(id: number): void { this.openings = this.openings.filter(o => o.id !== id); this.draw2D(); this.queue3D(); }
  clearLevel(): void {
    if (!confirm('Remove all rooms and furniture on this floor?')) return;
    const removed = this.rooms.filter(r => r.levelId === this.activeLevelId).map(r => r.id);
    this.rooms = this.rooms.filter(r => r.levelId !== this.activeLevelId);
    this.openings = this.openings.filter(o => !removed.includes(o.roomId));
    this.furniture = this.furniture.filter(f => f.levelId !== this.activeLevelId);
    this.selectedRoomId = null; this.draw2D(); this.queue3D();
  }
  savePlan(): void {
    const data: PlanFile = { version: 1, levels: this.levels, rooms: this.rooms, openings: this.openings, furniture: this.furniture, roofStyle: this.roofStyle, showRoof: this.showRoof };
    const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
    const link = document.createElement('a'); link.href = url; link.download = 'buildmind-plan.json'; link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  async loadPlan(event: Event): Promise<void> {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0]; if (!file) return;
    try {
      const data = JSON.parse(await file.text()) as PlanFile;
      if (data.version !== 1 || !Array.isArray(data.levels) || !Array.isArray(data.rooms) || !Array.isArray(data.openings) || !Array.isArray(data.furniture)) throw new Error('Invalid file');
      if (data.levels.length === 0 || data.levels.length > 3 || data.rooms.length > 150 || data.openings.length > 500 || data.furniture.length > 500) throw new Error('File exceeds limits');
      // Validate imported coordinates and sizes before using the model.
      const validNumber = (n: unknown) => typeof n === 'number' && Number.isFinite(n);
      if (data.rooms.some(r => ![r.x, r.y, r.width, r.height].every(validNumber) || r.width < 50 || r.height < 50 || r.width > 1000 || r.height > 700)) throw new Error('Invalid room geometry');
      if (data.openings.some(o => ![o.offset, o.width].every(validNumber) || o.width <= 0 || !['door', 'window'].includes(o.kind) || !['top', 'bottom', 'left', 'right'].includes(o.side))) throw new Error('Invalid openings');
      if (data.furniture.some(f => ![f.x, f.y, f.width, f.depth].every(validNumber) || f.width <= 0 || f.depth <= 0 || !['bed', 'sofa', 'table'].includes(f.kind))) throw new Error('Invalid furniture');
      this.levels = data.levels; this.rooms = data.rooms; this.openings = data.openings; this.furniture = data.furniture;
      this.roofStyle = data.roofStyle === 'gable' ? 'gable' : 'flat'; this.showRoof = !!data.showRoof;
      this.activeLevelId = this.levels[0].id; this.selectedRoomId = null;
      this.nextId = Math.max(1, ...this.levels.map(v => v.id), ...this.rooms.map(v => v.id), ...this.openings.map(v => v.id), ...this.furniture.map(v => v.id)) + 1;
      this.draw2D(); this.queue3D(); this.status = 'Plan loaded successfully.';
    } catch { this.status = 'Cannot load file: invalid BuildMind JSON.'; }
    input.value = '';
  }
  ngOnDestroy(): void {
    this.disposed = true;
    if (this.pendingFrame) cancelAnimationFrame(this.pendingFrame);
    this.stage?.destroy(); this.resizeObserver?.disconnect();
    if (this.renderer) this.renderer.setAnimationLoop(null);
    this.orbit?.dispose();
    if (this.scene) this.clear3D();
    this.renderer?.dispose(); this.renderer?.domElement.remove();
  }
}
