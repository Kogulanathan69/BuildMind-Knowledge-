# BuildMind 3D V2 Architectural

This frontend is a concept-style upgrade intended to look much closer to an architectural presentation model.

## Main upgrades

- Open-roof interior architectural view
- Full roof-on exterior view
- Better architectural camera framing
- Real wall gaps for doors and windows
- Window frames + transparent glazing
- Door frames + door panels
- Improved room floor materials
- Procedural furniture with more detail
- Living room sofa + TV + coffee table
- Beds with mattress, duvet, pillows, headboard, wardrobe
- Dining table + chairs
- L-shaped kitchen counters + island
- Bathroom toilet + sink + shower glass
- Gable roof with overhang + fascia
- Porch, path, lawns, trees and boundary curb
- Day / Warm lighting switch
- Furniture toggle
- Room-label toggle
- Reset camera
- Design A / B / C selection
- Existing n8n production webhook integration

## Install

```powershell
npm.cmd install
npm.cmd start
```

Open:

http://localhost:4200

n8n should be running on:

http://localhost:5678

and the production webhook should be:

POST /webhook/buildmind-generate

## Important

This is still a procedural concept renderer, not a photorealistic BIM/CAD engine.
It should look much closer to an architectural concept model, but exact photorealistic output
would require high-quality GLTF/3D assets, PBR textures, better boolean geometry and a more advanced renderer.
