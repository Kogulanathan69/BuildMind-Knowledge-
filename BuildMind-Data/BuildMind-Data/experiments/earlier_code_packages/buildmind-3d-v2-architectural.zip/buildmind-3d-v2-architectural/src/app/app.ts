
import {
  ChangeDetectorRef,
  Component,
  ElementRef,
  OnDestroy,
  ViewChild
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

type ViewMode = 'interior' | 'exterior';
type LightingMode = 'day' | 'warm';

interface Opening {
  start: number;
  end: number;
  bottom: number;
  top: number;
  kind: 'door' | 'window';
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App implements OnDestroy {
  @ViewChild('threeContainer') threeContainer?: ElementRef<HTMLDivElement>;

  userMessage = '';
  loading = false;
  generated = false;
  errorMessage = '';

  selectedDesign: any = null;
  designOptions: any[] = [];
  validation: any = null;
  rooms: any[] = [];
  doors: any[] = [];
  windows: any[] = [];
  land: any = null;

  safeSvg: SafeHtml | null = null;
  activeOptionName = '';

  show3D = false;
  viewMode: ViewMode = 'interior';
  lightingMode: LightingMode = 'day';
  furnitureVisible = true;
  labelsVisible = false;

  readonly samplePrompt =
    'I have a 40 x 60 ft land. I need 3 bedrooms, 2 bathrooms, ' +
    '1 car parking, a large kitchen and good ventilation.';

  private renderer?: THREE.WebGLRenderer;
  private scene?: THREE.Scene;
  private camera?: THREE.PerspectiveCamera;
  private controls?: OrbitControls;
  private animationId = 0;
  private resizeObserver?: ResizeObserver;

  private houseGroup = new THREE.Group();
  private roofGroup = new THREE.Group();
  private furnitureGroup = new THREE.Group();
  private exteriorGroup = new THREE.Group();
  private labelsGroup = new THREE.Group();
  private lightGroup = new THREE.Group();

  constructor(
    private http: HttpClient,
    private sanitizer: DomSanitizer,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnDestroy(): void {
    this.disposeThree();
  }

  useSample(): void {
    this.userMessage = this.samplePrompt;
  }

  generatePlan(): void {
    if (!this.userMessage.trim()) {
      this.errorMessage = 'Please enter your house requirements.';
      return;
    }

    this.disposeThree();
    this.loading = true;
    this.generated = false;
    this.errorMessage = '';
    this.safeSvg = null;
    this.show3D = false;

    this.http.post<any>(
      '/api/webhook/buildmind-generate',
      { message: this.userMessage.trim() }
    ).subscribe({
      next: (response) => {
        const data = Array.isArray(response) ? response[0] : response;

        this.land = data?.land ?? { width: 40, length: 60, unit: 'ft' };
        this.selectedDesign = data?.selectedDesign ?? null;
        this.designOptions = data?.designOptions ?? [];
        this.validation = data?.validation ?? null;
        this.rooms = data?.rooms ?? [];
        this.doors = data?.doors ?? [];
        this.windows = data?.windows ?? [];
        this.activeOptionName = this.selectedDesign?.name ?? '';

        const svg =
          typeof data?.svgPreview === 'string' && data.svgPreview.includes('<svg')
            ? data.svgPreview
            : this.buildSvg(
                this.rooms,
                this.doors,
                this.windows,
                this.selectedDesign?.name ?? 'Selected Design',
                this.selectedDesign?.score ?? null
              );

        this.safeSvg = this.sanitizer.bypassSecurityTrustHtml(svg);
        this.loading = false;
        this.generated = true;
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error('BuildMind error:', err);
        this.loading = false;
        this.generated = false;
        this.errorMessage =
          'Unable to generate the plan. Make sure n8n is running and the workflow is published.';
        this.cdr.detectChanges();
      }
    });
  }

  selectDesign(option: any): void {
    this.disposeThree();
    this.show3D = false;

    this.activeOptionName = option.name;
    this.selectedDesign = {
      name: option.name,
      strategy: option.strategy ?? '',
      score: option.score ?? 0,
      explanations: option.explanations ?? []
    };

    this.rooms = option.rooms ?? [];
    this.doors = option.doors ?? [];
    this.windows = option.windows ?? [];
    this.validation = option.validation ?? this.validation;

    this.safeSvg = this.sanitizer.bypassSecurityTrustHtml(
      this.buildSvg(
        this.rooms,
        this.doors,
        this.windows,
        option.name,
        option.score ?? null
      )
    );

    window.scrollTo({ top: 0, behavior: 'smooth' });
    this.cdr.detectChanges();
  }

  show2D(): void {
    this.show3D = false;
    this.disposeThree();
  }

  open3D(mode: ViewMode = 'interior'): void {
    if (!this.rooms.length) {
      this.errorMessage = 'Generate and select a 2D design first.';
      return;
    }

    this.show3D = true;
    this.viewMode = mode;
    this.errorMessage = '';
    this.cdr.detectChanges();

    setTimeout(() => {
      this.initThree();
      this.applyViewMode();
      this.applyLighting();
    }, 0);
  }

  setViewMode(mode: ViewMode): void {
    this.viewMode = mode;

    if (!this.show3D) {
      this.open3D(mode);
      return;
    }

    this.applyViewMode();
  }

  setLighting(mode: LightingMode): void {
    this.lightingMode = mode;
    this.applyLighting();
  }

  toggleFurniture(): void {
    this.furnitureVisible = !this.furnitureVisible;
    this.furnitureGroup.visible = this.furnitureVisible;
  }

  toggleLabels(): void {
    this.labelsVisible = !this.labelsVisible;
    this.labelsGroup.visible = this.labelsVisible;
  }

  resetCamera(): void {
    this.applyViewMode();
  }

  resetDesign(): void {
    this.disposeThree();

    this.userMessage = '';
    this.loading = false;
    this.generated = false;
    this.errorMessage = '';
    this.selectedDesign = null;
    this.designOptions = [];
    this.validation = null;
    this.rooms = [];
    this.doors = [];
    this.windows = [];
    this.land = null;
    this.safeSvg = null;
    this.activeOptionName = '';
    this.show3D = false;
    this.viewMode = 'interior';
    this.lightingMode = 'day';
    this.furnitureVisible = true;
    this.labelsVisible = false;

    this.cdr.detectChanges();
  }

  // ----------------------------------------------------------------
  // THREE.JS ARCHITECTURAL V2
  // ----------------------------------------------------------------

  private initThree(): void {
    const container = this.threeContainer?.nativeElement;
    if (!container) return;

    this.disposeThree();
    container.innerHTML = '';

    const width = Math.max(container.clientWidth, 720);
    const height = Math.max(container.clientHeight, 620);

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0xeef2f6);

    this.camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 2500);

    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: false
    });

    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.setSize(width, height);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;

    container.appendChild(this.renderer.domElement);

    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.08;
    this.controls.enablePan = true;
    this.controls.minPolarAngle = 0.25;
    this.controls.maxPolarAngle = Math.PI / 2.05;

    this.houseGroup = new THREE.Group();
    this.roofGroup = new THREE.Group();
    this.furnitureGroup = new THREE.Group();
    this.exteriorGroup = new THREE.Group();
    this.labelsGroup = new THREE.Group();
    this.lightGroup = new THREE.Group();

    this.scene.add(
      this.houseGroup,
      this.roofGroup,
      this.furnitureGroup,
      this.exteriorGroup,
      this.labelsGroup,
      this.lightGroup
    );

    this.addArchitecturalGround();
    this.addArchitecturalRooms();
    this.addArchitecturalFurniture();
    this.addArchitecturalRoof();
    this.addExteriorScene();
    this.addRoomLabels();
    this.addLights();

    this.furnitureGroup.visible = this.furnitureVisible;
    this.labelsGroup.visible = this.labelsVisible;

    this.resizeObserver = new ResizeObserver(() => {
      if (!this.renderer || !this.camera || !container) return;

      const w = Math.max(container.clientWidth, 360);
      const h = Math.max(container.clientHeight, 480);

      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h);
    });

    this.resizeObserver.observe(container);
    this.animate();
  }

  private applyViewMode(): void {
    if (!this.camera || !this.controls) return;

    const lw = Number(this.land?.width ?? 40);
    const ll = Number(this.land?.length ?? 60);
    const maxSide = Math.max(lw, ll);

    if (this.viewMode === 'interior') {
      this.roofGroup.visible = false;

      this.camera.position.set(
        lw * 1.05,
        maxSide * 0.95,
        ll * 1.05
      );

      this.controls.target.set(lw / 2, 1.15, ll / 2);
    } else {
      this.roofGroup.visible = true;

      this.camera.position.set(
        lw * 1.35,
        maxSide * 0.62,
        ll * 1.35
      );

      this.controls.target.set(lw / 2, 2.0, ll / 2);
    }

    this.controls.update();
  }

  private applyLighting(): void {
    if (!this.scene) return;

    if (this.lightingMode === 'warm') {
      this.scene.background = new THREE.Color(0xf3e7d6);
      this.renderer && (this.renderer.toneMappingExposure = 0.95);
    } else {
      this.scene.background = new THREE.Color(0xeef2f6);
      this.renderer && (this.renderer.toneMappingExposure = 1.05);
    }

    this.lightGroup.clear();
    this.addLights();
  }

  private addLights(): void {
    if (!this.scene) return;

    const warm = this.lightingMode === 'warm';

    const hemi = new THREE.HemisphereLight(
      warm ? 0xffe8c6 : 0xffffff,
      0x718096,
      warm ? 1.7 : 2.3
    );
    this.lightGroup.add(hemi);

    const sun = new THREE.DirectionalLight(
      warm ? 0xffd2a1 : 0xffffff,
      warm ? 2.6 : 3.1
    );
    sun.position.set(38, 70, 30);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    sun.shadow.camera.left = -100;
    sun.shadow.camera.right = 100;
    sun.shadow.camera.top = 100;
    sun.shadow.camera.bottom = -100;
    this.lightGroup.add(sun);

    const fill = new THREE.DirectionalLight(
      warm ? 0xffefe1 : 0xf4f8ff,
      warm ? 0.65 : 1.0
    );
    fill.position.set(-35, 25, -40);
    this.lightGroup.add(fill);
  }

  private addArchitecturalGround(): void {
    if (!this.scene) return;

    const lw = Number(this.land?.width ?? 40);
    const ll = Number(this.land?.length ?? 60);

    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(lw + 28, ll + 28),
      new THREE.MeshStandardMaterial({
        color: 0xe8ecef,
        roughness: 0.98
      })
    );

    ground.rotation.x = -Math.PI / 2;
    ground.position.set(lw / 2, -0.05, ll / 2);
    ground.receiveShadow = true;
    this.scene.add(ground);

    const site = new THREE.Mesh(
      new THREE.BoxGeometry(lw + 1.5, 0.08, ll + 1.5),
      new THREE.MeshStandardMaterial({
        color: 0xd9dde2,
        roughness: 0.92
      })
    );

    site.position.set(lw / 2, 0.02, ll / 2);
    site.receiveShadow = true;
    this.exteriorGroup.add(site);
  }

  // Create floors + segmented walls around actual door/window openings
  private addArchitecturalRooms(): void {
    const floorThickness = 0.18;
    const wallHeight = 3.25;
    const wallThickness = 0.22;

    for (const room of this.rooms) {
      const x = Number(room.x);
      const z = Number(room.y);
      const w = Number(room.width);
      const d = Number(room.height);

      const floor = new THREE.Mesh(
        new THREE.BoxGeometry(w, floorThickness, d),
        new THREE.MeshStandardMaterial({
          color: this.getRoomFloorColor(room.name, room.type),
          roughness: 0.72,
          metalness: 0.02
        })
      );

      floor.position.set(x + w / 2, floorThickness / 2, z + d / 2);
      floor.receiveShadow = true;
      this.houseGroup.add(floor);

      // subtle floor inset / rug effect
      const inset = Math.min(0.28, Math.min(w, d) * 0.04);
      if (w > 2 && d > 2) {
        const inner = new THREE.Mesh(
          new THREE.PlaneGeometry(Math.max(0.5, w - inset * 2), Math.max(0.5, d - inset * 2)),
          new THREE.MeshStandardMaterial({
            color: this.getRoomAccentColor(room.name),
            roughness: 0.9,
            transparent: true,
            opacity: 0.22
          })
        );

        inner.rotation.x = -Math.PI / 2;
        inner.position.set(x + w / 2, floorThickness + 0.01, z + d / 2);
        this.houseGroup.add(inner);
      }

      const wallMat = new THREE.MeshStandardMaterial({
        color: 0xf7f4ee,
        roughness: 0.82
      });

      // top, bottom, left, right walls
      this.addWallWithOpenings(room, 'top', wallHeight, wallThickness, wallMat);
      this.addWallWithOpenings(room, 'bottom', wallHeight, wallThickness, wallMat);
      this.addWallWithOpenings(room, 'left', wallHeight, wallThickness, wallMat);
      this.addWallWithOpenings(room, 'right', wallHeight, wallThickness, wallMat);
    }

    this.addDoorFrames();
    this.addWindowFrames();
  }

  private addWallWithOpenings(
    room: any,
    side: 'top' | 'bottom' | 'left' | 'right',
    wallHeight: number,
    wallThickness: number,
    material: THREE.Material
  ): void {
    const x = Number(room.x);
    const z = Number(room.y);
    const w = Number(room.width);
    const d = Number(room.height);

    const horizontal = side === 'top' || side === 'bottom';
    const wallLength = horizontal ? w : d;

    const openings = this.collectOpeningsForWall(room, side, wallHeight)
      .sort((a, b) => a.start - b.start);

    let cursor = 0;

    for (const opening of openings) {
      if (opening.start > cursor) {
        this.createWallSegment(
          room, side,
          cursor,
          opening.start - cursor,
          0,
          wallHeight,
          wallThickness,
          material
        );
      }

      if (opening.kind === 'window') {
        if (opening.bottom > 0) {
          this.createWallSegment(
            room, side,
            opening.start,
            opening.end - opening.start,
            0,
            opening.bottom,
            wallThickness,
            material
          );
        }

        if (opening.top < wallHeight) {
          this.createWallSegment(
            room, side,
            opening.start,
            opening.end - opening.start,
            opening.top,
            wallHeight - opening.top,
            wallThickness,
            material
          );
        }
      } else if (opening.kind === 'door') {
        if (opening.top < wallHeight) {
          this.createWallSegment(
            room, side,
            opening.start,
            opening.end - opening.start,
            opening.top,
            wallHeight - opening.top,
            wallThickness,
            material
          );
        }
      }

      cursor = Math.max(cursor, opening.end);
    }

    if (cursor < wallLength) {
      this.createWallSegment(
        room, side,
        cursor,
        wallLength - cursor,
        0,
        wallHeight,
        wallThickness,
        material
      );
    }
  }

  private collectOpeningsForWall(room: any, side: string, wallHeight: number): Opening[] {
    const openings: Opening[] = [];

    const rx = Number(room.x);
    const rz = Number(room.y);
    const rw = Number(room.width);
    const rd = Number(room.height);

    const eps = 0.35;

    for (const door of this.doors) {
      const dx = Number(door.x);
      const dz = Number(door.y);
      const dw = Number(door.width ?? 3);

      if ((side === 'top' || side === 'bottom') && door.orientation !== 'horizontal') continue;
      if ((side === 'left' || side === 'right') && door.orientation !== 'vertical') continue;

      if (side === 'top' && Math.abs(dz - rz) <= eps && dx >= rx - eps && dx <= rx + rw + eps) {
        openings.push({
          start: THREE.MathUtils.clamp(dx - rx, 0, rw),
          end: THREE.MathUtils.clamp(dx - rx + dw, 0, rw),
          bottom: 0,
          top: 2.35,
          kind: 'door'
        });
      }

      if (side === 'bottom' && Math.abs(dz - (rz + rd)) <= eps && dx >= rx - eps && dx <= rx + rw + eps) {
        openings.push({
          start: THREE.MathUtils.clamp(dx - rx, 0, rw),
          end: THREE.MathUtils.clamp(dx - rx + dw, 0, rw),
          bottom: 0,
          top: 2.35,
          kind: 'door'
        });
      }

      if (side === 'left' && Math.abs(dx - rx) <= eps && dz >= rz - eps && dz <= rz + rd + eps) {
        openings.push({
          start: THREE.MathUtils.clamp(dz - rz, 0, rd),
          end: THREE.MathUtils.clamp(dz - rz + dw, 0, rd),
          bottom: 0,
          top: 2.35,
          kind: 'door'
        });
      }

      if (side === 'right' && Math.abs(dx - (rx + rw)) <= eps && dz >= rz - eps && dz <= rz + rd + eps) {
        openings.push({
          start: THREE.MathUtils.clamp(dz - rz, 0, rd),
          end: THREE.MathUtils.clamp(dz - rz + dw, 0, rd),
          bottom: 0,
          top: 2.35,
          kind: 'door'
        });
      }
    }

    for (const win of this.windows) {
      const wx = Number(win.x);
      const wz = Number(win.y);
      const ww = Number(win.width ?? 4);

      if ((side === 'top' || side === 'bottom') && win.orientation !== 'horizontal') continue;
      if ((side === 'left' || side === 'right') && win.orientation !== 'vertical') continue;

      if (side === 'top' && Math.abs(wz - rz) <= eps && wx >= rx - eps && wx <= rx + rw + eps) {
        openings.push({
          start: THREE.MathUtils.clamp(wx - rx, 0, rw),
          end: THREE.MathUtils.clamp(wx - rx + ww, 0, rw),
          bottom: 1.0,
          top: Math.min(2.25, wallHeight - 0.3),
          kind: 'window'
        });
      }

      if (side === 'bottom' && Math.abs(wz - (rz + rd)) <= eps && wx >= rx - eps && wx <= rx + rw + eps) {
        openings.push({
          start: THREE.MathUtils.clamp(wx - rx, 0, rw),
          end: THREE.MathUtils.clamp(wx - rx + ww, 0, rw),
          bottom: 1.0,
          top: Math.min(2.25, wallHeight - 0.3),
          kind: 'window'
        });
      }

      if (side === 'left' && Math.abs(wx - rx) <= eps && wz >= rz - eps && wz <= rz + rd + eps) {
        openings.push({
          start: THREE.MathUtils.clamp(wz - rz, 0, rd),
          end: THREE.MathUtils.clamp(wz - rz + ww, 0, rd),
          bottom: 1.0,
          top: Math.min(2.25, wallHeight - 0.3),
          kind: 'window'
        });
      }

      if (side === 'right' && Math.abs(wx - (rx + rw)) <= eps && wz >= rz - eps && wz <= rz + rd + eps) {
        openings.push({
          start: THREE.MathUtils.clamp(wz - rz, 0, rd),
          end: THREE.MathUtils.clamp(wz - rz + ww, 0, rd),
          bottom: 1.0,
          top: Math.min(2.25, wallHeight - 0.3),
          kind: 'window'
        });
      }
    }

    return openings.filter(o => o.end - o.start > 0.12);
  }

  private createWallSegment(
    room: any,
    side: 'top' | 'bottom' | 'left' | 'right',
    start: number,
    length: number,
    yBottom: number,
    height: number,
    thickness: number,
    material: THREE.Material
  ): void {
    if (length <= 0.05 || height <= 0.05) return;

    const rx = Number(room.x);
    const rz = Number(room.y);
    const rw = Number(room.width);
    const rd = Number(room.height);

    let width = 0;
    let depth = 0;
    let px = 0;
    let pz = 0;

    if (side === 'top') {
      width = length;
      depth = thickness;
      px = rx + start + length / 2;
      pz = rz;
    } else if (side === 'bottom') {
      width = length;
      depth = thickness;
      px = rx + start + length / 2;
      pz = rz + rd;
    } else if (side === 'left') {
      width = thickness;
      depth = length;
      px = rx;
      pz = rz + start + length / 2;
    } else {
      width = thickness;
      depth = length;
      px = rx + rw;
      pz = rz + start + length / 2;
    }

    const mesh = new THREE.Mesh(
      new THREE.BoxGeometry(width, height, depth),
      material
    );

    mesh.position.set(px, yBottom + height / 2 + 0.18, pz);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    this.houseGroup.add(mesh);
  }

  private addDoorFrames(): void {
    const frameMat = new THREE.MeshStandardMaterial({
      color: 0x6f4a2e,
      roughness: 0.7
    });

    const panelMat = new THREE.MeshStandardMaterial({
      color: 0xb77b48,
      roughness: 0.72
    });

    for (const door of this.doors) {
      const x = Number(door.x);
      const z = Number(door.y);
      const size = Number(door.width ?? 3);
      const frameT = 0.10;
      const doorH = 2.25;

      const group = new THREE.Group();

      if (door.orientation === 'vertical') {
        const top = new THREE.Mesh(new THREE.BoxGeometry(frameT, frameT, size), frameMat);
        top.position.set(x, doorH, z + size / 2);

        const post1 = new THREE.Mesh(new THREE.BoxGeometry(frameT, doorH, frameT), frameMat);
        post1.position.set(x, doorH / 2, z);

        const post2 = post1.clone();
        post2.position.z = z + size;

        const panel = new THREE.Mesh(new THREE.BoxGeometry(0.06, doorH * 0.94, size * 0.92), panelMat);
        panel.position.set(x + 0.03, doorH * 0.47, z + size / 2);

        group.add(top, post1, post2, panel);
      } else {
        const top = new THREE.Mesh(new THREE.BoxGeometry(size, frameT, frameT), frameMat);
        top.position.set(x + size / 2, doorH, z);

        const post1 = new THREE.Mesh(new THREE.BoxGeometry(frameT, doorH, frameT), frameMat);
        post1.position.set(x, doorH / 2, z);

        const post2 = post1.clone();
        post2.position.x = x + size;

        const panel = new THREE.Mesh(new THREE.BoxGeometry(size * 0.92, doorH * 0.94, 0.06), panelMat);
        panel.position.set(x + size / 2, doorH * 0.47, z + 0.03);

        group.add(top, post1, post2, panel);
      }

      this.houseGroup.add(group);
    }
  }

  private addWindowFrames(): void {
    const frameMat = new THREE.MeshStandardMaterial({
      color: 0x2f3842,
      roughness: 0.4,
      metalness: 0.15
    });

    const glassMat = new THREE.MeshPhysicalMaterial({
      color: 0xa9d8f7,
      transparent: true,
      opacity: 0.38,
      transmission: 0.35,
      roughness: 0.08,
      metalness: 0.0
    });

    for (const win of this.windows) {
      const x = Number(win.x);
      const z = Number(win.y);
      const size = Number(win.width ?? 4);
      const bottom = 1.0;
      const height = 1.25;

      if (win.orientation === 'vertical') {
        const glass = new THREE.Mesh(
          new THREE.BoxGeometry(0.04, height, size),
          glassMat
        );
        glass.position.set(x, bottom + height / 2, z + size / 2);

        const frame1 = new THREE.Mesh(new THREE.BoxGeometry(0.08, height + 0.1, 0.08), frameMat);
        frame1.position.set(x, bottom + height / 2, z);

        const frame2 = frame1.clone();
        frame2.position.z = z + size;

        const mid = new THREE.Mesh(new THREE.BoxGeometry(0.08, height + 0.1, 0.06), frameMat);
        mid.position.set(x, bottom + height / 2, z + size / 2);

        const top = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.08, size), frameMat);
        top.position.set(x, bottom + height, z + size / 2);

        const bot = top.clone();
        bot.position.y = bottom;

        this.houseGroup.add(glass, frame1, frame2, mid, top, bot);
      } else {
        const glass = new THREE.Mesh(
          new THREE.BoxGeometry(size, height, 0.04),
          glassMat
        );
        glass.position.set(x + size / 2, bottom + height / 2, z);

        const frame1 = new THREE.Mesh(new THREE.BoxGeometry(0.08, height + 0.1, 0.08), frameMat);
        frame1.position.set(x, bottom + height / 2, z);

        const frame2 = frame1.clone();
        frame2.position.x = x + size;

        const mid = new THREE.Mesh(new THREE.BoxGeometry(0.06, height + 0.1, 0.08), frameMat);
        mid.position.set(x + size / 2, bottom + height / 2, z);

        const top = new THREE.Mesh(new THREE.BoxGeometry(size, 0.08, 0.08), frameMat);
        top.position.set(x + size / 2, bottom + height, z);

        const bot = top.clone();
        bot.position.y = bottom;

        this.houseGroup.add(glass, frame1, frame2, mid, top, bot);
      }
    }
  }

  private addArchitecturalFurniture(): void {
    for (const room of this.rooms) {
      const name = String(room.name || '').toLowerCase();

      if (name.includes('living')) {
        this.addLivingFurniture(room);
      } else if (name.includes('master')) {
        this.addBedroomFurniture(room, true);
      } else if (name.includes('bedroom')) {
        this.addBedroomFurniture(room, false);
      } else if (name.includes('dining')) {
        this.addDiningFurniture(room);
      } else if (name.includes('kitchen')) {
        this.addKitchenFurniture(room);
      } else if (name.includes('bath')) {
        this.addBathroomFurniture(room);
      }
    }
  }

  private addLivingFurniture(room: any): void {
    const x = Number(room.x);
    const z = Number(room.y);
    const w = Number(room.width);
    const d = Number(room.height);

    const sofaMat = new THREE.MeshStandardMaterial({
      color: 0xb7b8bc,
      roughness: 0.9
    });

    const woodMat = new THREE.MeshStandardMaterial({
      color: 0x9c6b43,
      roughness: 0.72
    });

    const sofaWidth = Math.min(7.5, Math.max(4.5, w * 0.45));
    const seat = new THREE.Mesh(
      new THREE.BoxGeometry(sofaWidth, 0.55, 2.0),
      sofaMat
    );
    seat.position.set(x + Math.min(sofaWidth / 2 + 1, w / 2), 0.42, z + 2.2);

    const back = new THREE.Mesh(
      new THREE.BoxGeometry(sofaWidth, 1.0, 0.35),
      sofaMat
    );
    back.position.set(seat.position.x, 1.05, z + 1.25);

    const arm1 = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.85, 2.0), sofaMat);
    arm1.position.set(seat.position.x - sofaWidth / 2, 0.65, z + 2.2);
    const arm2 = arm1.clone();
    arm2.position.x = seat.position.x + sofaWidth / 2;

    const table = new THREE.Mesh(
      new THREE.BoxGeometry(Math.min(3.5, w * 0.25), 0.22, 1.6),
      woodMat
    );
    table.position.set(x + w * 0.62, 0.48, z + Math.min(4.4, d * 0.42));

    const tvStand = new THREE.Mesh(
      new THREE.BoxGeometry(Math.min(5.0, w * 0.35), 0.65, 0.65),
      woodMat
    );
    tvStand.position.set(x + w / 2, 0.34, z + d - 0.6);

    const tv = new THREE.Mesh(
      new THREE.BoxGeometry(Math.min(4.2, w * 0.3), 2.2, 0.12),
      new THREE.MeshStandardMaterial({ color: 0x20252b, roughness: 0.25 })
    );
    tv.position.set(x + w / 2, 1.75, z + d - 0.48);

    [seat, back, arm1, arm2, table, tvStand, tv].forEach(m => {
      m.castShadow = true;
      m.receiveShadow = true;
      this.furnitureGroup.add(m);
    });
  }

  private addBedroomFurniture(room: any, master: boolean): void {
    const x = Number(room.x);
    const z = Number(room.y);
    const w = Number(room.width);
    const d = Number(room.height);

    const bedW = Math.min(master ? 6.2 : 4.6, Math.max(3.5, w - 1.6));
    const bedD = Math.min(6.6, Math.max(5.0, d - 1.8));

    const frameMat = new THREE.MeshStandardMaterial({
      color: 0x8b6a4d,
      roughness: 0.82
    });

    const mattressMat = new THREE.MeshStandardMaterial({
      color: master ? 0xf5f1ea : 0xf0f3fa,
      roughness: 0.95
    });

    const duvetMat = new THREE.MeshStandardMaterial({
      color: master ? 0xcdd9ee : 0xdce5f7,
      roughness: 0.95
    });

    const base = new THREE.Mesh(new THREE.BoxGeometry(bedW, 0.45, bedD), frameMat);
    base.position.set(x + w / 2, 0.35, z + d / 2);

    const mattress = new THREE.Mesh(new THREE.BoxGeometry(bedW - 0.14, 0.34, bedD - 0.15), mattressMat);
    mattress.position.set(x + w / 2, 0.72, z + d / 2);

    const duvet = new THREE.Mesh(new THREE.BoxGeometry(bedW - 0.28, 0.14, bedD * 0.62), duvetMat);
    duvet.position.set(x + w / 2, 0.96, z + d / 2 + bedD * 0.08);

    const headboard = new THREE.Mesh(new THREE.BoxGeometry(bedW, 1.55, 0.22), frameMat);
    headboard.position.set(x + w / 2, 1.22, z + d / 2 - bedD / 2);

    const pillowMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 1
    });

    for (const offset of [-bedW * 0.22, bedW * 0.22]) {
      const pillow = new THREE.Mesh(new THREE.BoxGeometry(bedW * 0.32, 0.16, 0.85), pillowMat);
      pillow.position.set(x + w / 2 + offset, 1.02, z + d / 2 - bedD * 0.26);
      this.furnitureGroup.add(pillow);
    }

    const wardrobe = new THREE.Mesh(
      new THREE.BoxGeometry(Math.min(3.5, w * 0.28), 2.3, 0.65),
      new THREE.MeshStandardMaterial({
        color: 0xb18a64,
        roughness: 0.82
      })
    );
    wardrobe.position.set(x + 0.7, 1.15, z + d - 0.65);

    [base, mattress, duvet, headboard, wardrobe].forEach(m => {
      m.castShadow = true;
      m.receiveShadow = true;
      this.furnitureGroup.add(m);
    });
  }

  private addDiningFurniture(room: any): void {
    const x = Number(room.x);
    const z = Number(room.y);
    const w = Number(room.width);
    const d = Number(room.height);

    const cx = x + w / 2;
    const cz = z + d / 2;

    const woodMat = new THREE.MeshStandardMaterial({
      color: 0x9b6a43,
      roughness: 0.72
    });

    const table = new THREE.Mesh(
      new THREE.BoxGeometry(Math.min(5.2, w - 1.3), 0.22, 2.5),
      woodMat
    );
    table.position.set(cx, 0.88, cz);
    table.castShadow = true;
    this.furnitureGroup.add(table);

    const chairPositions = [
      [cx - 1.7, cz - 1.8, 0],
      [cx + 1.7, cz - 1.8, 0],
      [cx - 1.7, cz + 1.8, Math.PI],
      [cx + 1.7, cz + 1.8, Math.PI]
    ];

    for (const [px, pz, rot] of chairPositions) {
      const chair = new THREE.Group();

      const seat = new THREE.Mesh(
        new THREE.BoxGeometry(0.8, 0.18, 0.8),
        woodMat
      );
      seat.position.y = 0.55;

      const back = new THREE.Mesh(
        new THREE.BoxGeometry(0.8, 1.0, 0.12),
        woodMat
      );
      back.position.set(0, 1.0, -0.34);

      chair.add(seat, back);
      chair.position.set(px, 0, pz);
      chair.rotation.y = rot;
      this.furnitureGroup.add(chair);
    }
  }

  private addKitchenFurniture(room: any): void {
    const x = Number(room.x);
    const z = Number(room.y);
    const w = Number(room.width);
    const d = Number(room.height);

    const cabinetMat = new THREE.MeshStandardMaterial({
      color: 0xe4ded6,
      roughness: 0.76
    });

    const topMat = new THREE.MeshStandardMaterial({
      color: 0x6f767e,
      roughness: 0.55
    });

    const counterDepth = 1.2;

    const base1 = new THREE.Mesh(
      new THREE.BoxGeometry(Math.max(3.0, w - 1.2), 0.9, counterDepth),
      cabinetMat
    );
    base1.position.set(x + w / 2, 0.45, z + 0.75);

    const top1 = new THREE.Mesh(
      new THREE.BoxGeometry(Math.max(3.0, w - 1.1), 0.10, counterDepth + 0.08),
      topMat
    );
    top1.position.set(x + w / 2, 0.95, z + 0.75);

    const base2 = new THREE.Mesh(
      new THREE.BoxGeometry(counterDepth, 0.9, Math.max(3.0, d * 0.55)),
      cabinetMat
    );
    base2.position.set(x + 0.75, 0.45, z + d * 0.52);

    const top2 = new THREE.Mesh(
      new THREE.BoxGeometry(counterDepth + 0.08, 0.10, Math.max(3.0, d * 0.55)),
      topMat
    );
    top2.position.set(x + 0.75, 0.95, z + d * 0.52);

    const island = new THREE.Mesh(
      new THREE.BoxGeometry(Math.min(4.0, w * 0.32), 0.92, 1.6),
      cabinetMat
    );
    island.position.set(x + w * 0.65, 0.46, z + d * 0.62);

    [base1, top1, base2, top2, island].forEach(m => {
      m.castShadow = true;
      m.receiveShadow = true;
      this.furnitureGroup.add(m);
    });
  }

  private addBathroomFurniture(room: any): void {
    const x = Number(room.x);
    const z = Number(room.y);
    const w = Number(room.width);
    const d = Number(room.height);

    const ceramic = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.38
    });

    const toiletBase = new THREE.Mesh(
      new THREE.CylinderGeometry(0.48, 0.60, 0.55, 24),
      ceramic
    );
    toiletBase.position.set(x + 1.0, 0.28, z + 1.2);

    const tank = new THREE.Mesh(
      new THREE.BoxGeometry(0.8, 0.85, 0.35),
      ceramic
    );
    tank.position.set(x + 1.0, 0.95, z + 0.75);

    const sink = new THREE.Mesh(
      new THREE.BoxGeometry(1.15, 0.18, 0.72),
      ceramic
    );
    sink.position.set(x + w - 1.0, 0.92, z + 1.0);

    const showerGlass = new THREE.Mesh(
      new THREE.BoxGeometry(Math.min(2.2, w * 0.35), 2.0, 0.06),
      new THREE.MeshPhysicalMaterial({
        color: 0xbfe7ff,
        transparent: true,
        opacity: 0.25,
        transmission: 0.5,
        roughness: 0.05
      })
    );
    showerGlass.position.set(x + w - 1.2, 1.0, z + d - 1.0);

    [toiletBase, tank, sink, showerGlass].forEach(m => {
      m.castShadow = true;
      this.furnitureGroup.add(m);
    });
  }

  private addArchitecturalRoof(): void {
    const lw = Number(this.land?.width ?? 40);
    const ll = Number(this.land?.length ?? 60);

    const roofY = 3.5;
    const overhang = 0.7;
    const slopeRise = Math.max(2.0, lw * 0.10);

    const roofMat = new THREE.MeshStandardMaterial({
      color: 0xb95f43,
      roughness: 0.84,
      side: THREE.DoubleSide
    });

    const trimMat = new THREE.MeshStandardMaterial({
      color: 0xf0ede7,
      roughness: 0.82
    });

    // Left slope
    const leftShape = new THREE.Shape();
    leftShape.moveTo(-overhang, 0);
    leftShape.lineTo(lw / 2, slopeRise);
    leftShape.lineTo(lw / 2, slopeRise + 0.12);
    leftShape.lineTo(-overhang, 0.12);
    leftShape.closePath();

    const leftGeo = new THREE.ExtrudeGeometry(leftShape, {
      depth: ll + overhang * 2,
      bevelEnabled: false
    });

    const left = new THREE.Mesh(leftGeo, roofMat);
    left.position.set(0, roofY, -overhang);
    left.castShadow = true;

    // Right slope
    const rightShape = new THREE.Shape();
    rightShape.moveTo(0, slopeRise);
    rightShape.lineTo(lw / 2 + overhang, 0);
    rightShape.lineTo(lw / 2 + overhang, 0.12);
    rightShape.lineTo(0, slopeRise + 0.12);
    rightShape.closePath();

    const rightGeo = new THREE.ExtrudeGeometry(rightShape, {
      depth: ll + overhang * 2,
      bevelEnabled: false
    });

    const right = new THREE.Mesh(rightGeo, roofMat);
    right.position.set(lw / 2, roofY, -overhang);
    right.castShadow = true;

    // fascia trims
    const fascia1 = new THREE.Mesh(
      new THREE.BoxGeometry(lw + overhang * 2, 0.18, 0.15),
      trimMat
    );
    fascia1.position.set(lw / 2, roofY + 0.05, -overhang);

    const fascia2 = fascia1.clone();
    fascia2.position.z = ll + overhang;

    this.roofGroup.add(left, right, fascia1, fascia2);
  }

  private addExteriorScene(): void {
    const lw = Number(this.land?.width ?? 40);
    const ll = Number(this.land?.length ?? 60);

    const stone = new THREE.MeshStandardMaterial({
      color: 0xc8c3ba,
      roughness: 0.95
    });

    const grassMat = new THREE.MeshStandardMaterial({
      color: 0x91bd74,
      roughness: 1.0
    });

    const porch = new THREE.Mesh(
      new THREE.BoxGeometry(Math.min(10, lw * 0.32), 0.18, 2.2),
      stone
    );
    porch.position.set(lw * 0.32, 0.09, -1.0);

    const path = new THREE.Mesh(
      new THREE.BoxGeometry(3.2, 0.06, 8),
      stone
    );
    path.position.set(lw * 0.32, 0.03, -5.0);

    const lawn1 = new THREE.Mesh(
      new THREE.BoxGeometry(Math.max(5, lw * 0.18), 0.05, 6),
      grassMat
    );
    lawn1.position.set(lw * 0.10, 0.025, -4.0);

    const lawn2 = lawn1.clone();
    lawn2.position.set(lw * 0.55, 0.025, -4.0);

    const treeMat = new THREE.MeshStandardMaterial({
      color: 0x4c7f42,
      roughness: 1
    });
    const trunkMat = new THREE.MeshStandardMaterial({
      color: 0x7d5b3b,
      roughness: 1
    });

    for (const tx of [lw * 0.08, lw * 0.82]) {
      const trunk = new THREE.Mesh(
        new THREE.CylinderGeometry(0.18, 0.22, 1.4, 12),
        trunkMat
      );
      trunk.position.set(tx, 0.7, -4.5);

      const crown = new THREE.Mesh(
        new THREE.SphereGeometry(0.85, 16, 12),
        treeMat
      );
      crown.position.set(tx, 1.9, -4.5);

      this.exteriorGroup.add(trunk, crown);
    }

    this.exteriorGroup.add(porch, path, lawn1, lawn2);

    // subtle boundary curb
    const curbMat = new THREE.MeshStandardMaterial({
      color: 0xb7bcc4,
      roughness: 0.95
    });

    const curbFront = new THREE.Mesh(
      new THREE.BoxGeometry(lw + 2, 0.12, 0.22),
      curbMat
    );
    curbFront.position.set(lw / 2, 0.06, ll + 0.7);

    const curbBack = curbFront.clone();
    curbBack.position.z = -0.7;

    const curbL = new THREE.Mesh(
      new THREE.BoxGeometry(0.22, 0.12, ll + 1.4),
      curbMat
    );
    curbL.position.set(-0.7, 0.06, ll / 2);

    const curbR = curbL.clone();
    curbR.position.x = lw + 0.7;

    this.exteriorGroup.add(curbFront, curbBack, curbL, curbR);
  }

  private addRoomLabels(): void {
    for (const room of this.rooms) {
      const canvas = document.createElement('canvas');
      canvas.width = 512;
      canvas.height = 128;

      const ctx = canvas.getContext('2d');
      if (!ctx) continue;

      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = 'rgba(255,255,255,0.88)';
      ctx.fillRect(8, 8, 496, 112);

      ctx.fillStyle = '#23314f';
      ctx.font = 'bold 34px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(String(room.name), 256, 64);

      const texture = new THREE.CanvasTexture(canvas);
      texture.colorSpace = THREE.SRGBColorSpace;

      const sprite = new THREE.Sprite(
        new THREE.SpriteMaterial({
          map: texture,
          transparent: true,
          depthTest: false
        })
      );

      sprite.scale.set(4.8, 1.2, 1);
      sprite.position.set(
        Number(room.x) + Number(room.width) / 2,
        2.65,
        Number(room.y) + Number(room.height) / 2
      );

      this.labelsGroup.add(sprite);
    }
  }

  private getRoomFloorColor(name: string, type?: string): number {
    const n = String(name || '').toLowerCase();
    const t = String(type || '').toLowerCase();

    if (n.includes('living')) return 0xe9dfc9;
    if (n.includes('kitchen')) return 0xe7e3dd;
    if (n.includes('dining')) return 0xeadfca;
    if (n.includes('master')) return 0xd9d3c8;
    if (n.includes('bedroom')) return 0xdfd9ce;
    if (n.includes('bath')) return 0xd8e5e8;
    if (n.includes('parking')) return 0xcfd2d6;
    if (n.includes('corridor')) return 0xe8e5df;
    if (n.includes('backyard') || n.includes('utility') || t === 'open-space') return 0xcfe3c5;

    return 0xe5e2dc;
  }

  private getRoomAccentColor(name: string): number {
    const n = String(name || '').toLowerCase();
    if (n.includes('bath')) return 0xb7d6dd;
    if (n.includes('bedroom') || n.includes('master')) return 0xb8c8df;
    if (n.includes('living') || n.includes('dining')) return 0xd5bea0;
    if (n.includes('kitchen')) return 0xc7cbc9;
    return 0xd0d4d8;
  }

  private animate = (): void => {
    if (!this.renderer || !this.scene || !this.camera) return;

    this.animationId = requestAnimationFrame(this.animate);
    this.controls?.update();
    this.renderer.render(this.scene, this.camera);
  };

  private disposeThree(): void {
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
      this.animationId = 0;
    }

    this.resizeObserver?.disconnect();
    this.resizeObserver = undefined;

    this.controls?.dispose();
    this.controls = undefined;

    if (this.scene) {
      this.scene.traverse((obj) => {
        const mesh = obj as THREE.Mesh;

        if (mesh.geometry) {
          mesh.geometry.dispose();
        }

        const material = mesh.material as THREE.Material | THREE.Material[] | undefined;

        if (Array.isArray(material)) {
          material.forEach(m => m.dispose());
        } else {
          material?.dispose();
        }
      });
    }

    this.renderer?.dispose();

    const container = this.threeContainer?.nativeElement;
    if (container) {
      container.innerHTML = '';
    }

    this.renderer = undefined;
    this.scene = undefined;
    this.camera = undefined;

    this.houseGroup = new THREE.Group();
    this.roofGroup = new THREE.Group();
    this.furnitureGroup = new THREE.Group();
    this.exteriorGroup = new THREE.Group();
    this.labelsGroup = new THREE.Group();
    this.lightGroup = new THREE.Group();
  }

  // ----------------------------------------------------------------
  // SIMPLE 2D FALLBACK RENDERER
  // ----------------------------------------------------------------

  private buildSvg(
    rooms: any[],
    doors: any[],
    windows: any[],
    name: string,
    score: number | null
  ): string {
    const lw = Number(this.land?.width ?? 40);
    const ll = Number(this.land?.length ?? 60);
    const unit = String(this.land?.unit ?? 'ft');

    const W = 900;
    const H = 760;
    const L = 70;
    const T = 100;
    const R = 150;
    const B = 70;

    const s = Math.min((W - L - R) / lw, (H - T - B) / ll);

    const pxX = (x: number) => L + x * s;
    const pxY = (y: number) => T + y * s;

    const esc = (v: any) =>
      String(v ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');

    const color = (r: any) => {
      const n = String(r.name || '').toLowerCase();

      if (n.includes('backyard') || n.includes('utility')) return '#edf8e8';
      if (n.includes('living')) return '#fff5dc';
      if (n.includes('kitchen')) return '#ffeede';
      if (n.includes('dining')) return '#fff8dc';
      if (n.includes('master')) return '#e8efff';
      if (n.includes('bedroom')) return '#f0f4ff';
      if (n.includes('bath')) return '#e4f6ff';
      if (n.includes('parking')) return '#eeeeee';
      if (n.includes('corridor')) return '#f8f8f8';

      return '#f7f7f7';
    };

    let svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
      <rect width="100%" height="100%" fill="white"/>
      <text x="${W / 2}" y="32" text-anchor="middle" font-size="24" font-family="Arial" font-weight="bold">BuildMind - AI Generated 2D Floor Plan</text>
      <text x="${W / 2}" y="55" text-anchor="middle" font-size="12" font-family="Arial" fill="#667085">Interactive Design Preview</text>
      <text x="${L}" y="80" font-size="14" font-family="Arial" font-weight="bold" fill="#3157ff">${esc(name)}</text>
      ${score !== null ? `<text x="${L + 180}" y="80" font-size="13" font-family="Arial" font-weight="bold" fill="#059669">AI Score: ${score}</text>` : ''}
      <text x="${L + (lw * s) / 2}" y="${T - 18}" text-anchor="middle" font-size="13" font-family="Arial" font-weight="bold">FRONT / ROAD</text>
      <rect x="${L}" y="${T}" width="${lw * s}" height="${ll * s}" fill="white" stroke="#111" stroke-width="5"/>`;

    for (const r of rooms) {
      const x = pxX(r.x);
      const y = pxY(r.y);
      const w = r.width * s;
      const h = r.height * s;
      const fs = r.width * r.height < 45 ? 9 : 11;

      svg += `<g>
        <rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${color(r)}" stroke="#1f2937" stroke-width="2"/>
        <text x="${x + w / 2}" y="${y + h / 2 - 5}" text-anchor="middle" font-family="Arial" font-size="${fs}" font-weight="bold">${esc(r.name)}</text>
        <text x="${x + w / 2}" y="${y + h / 2 + 12}" text-anchor="middle" font-family="Arial" font-size="${Math.max(fs - 1, 8)}">${r.width} × ${r.height} ${esc(unit)}</text>
      </g>`;
    }

    for (const d of doors) {
      const x = pxX(d.x);
      const y = pxY(d.y);
      const z = (d.width ?? 3) * s;

      if (d.orientation === 'vertical') {
        svg += `<line x1="${x}" y1="${y}" x2="${x}" y2="${y + z}" stroke="white" stroke-width="7"/>
          <line x1="${x}" y1="${y}" x2="${x + z}" y2="${y}" stroke="#92400e" stroke-width="2"/>`;
      } else {
        svg += `<line x1="${x}" y1="${y}" x2="${x + z}" y2="${y}" stroke="white" stroke-width="7"/>
          <line x1="${x}" y1="${y}" x2="${x}" y2="${y + z}" stroke="#92400e" stroke-width="2"/>`;
      }
    }

    for (const w of windows) {
      const x = pxX(w.x);
      const y = pxY(w.y);
      const z = (w.width ?? 4) * s;

      if (w.orientation === 'vertical') {
        svg += `<line x1="${x}" y1="${y}" x2="${x}" y2="${y + z}" stroke="#2563eb" stroke-width="4"/>`;
      } else {
        svg += `<line x1="${x}" y1="${y}" x2="${x + z}" y2="${y}" stroke="#2563eb" stroke-width="4"/>`;
      }
    }

    svg += `<text x="${W / 2}" y="${H - 18}" text-anchor="middle" font-family="Arial" font-size="10" fill="#667085">BuildMind Concept Plan — Final construction drawings require professional review.</text></svg>`;

    return svg;
  }
}
