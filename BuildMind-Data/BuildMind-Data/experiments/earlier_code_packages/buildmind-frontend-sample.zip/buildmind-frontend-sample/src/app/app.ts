import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  userMessage = '';
  loading = false;
  errorMessage = '';
  generated = false;

  selectedDesign: any = null;
  designOptions: any[] = [];
  validation: any = null;
  rooms: any[] = [];
  safeSvg: SafeHtml | null = null;

  readonly samplePrompt =
    'I have a 40 x 60 ft land. I need 3 bedrooms, 2 bathrooms, ' +
    '1 car parking, a large kitchen and good ventilation.';

  constructor(
    private http: HttpClient,
    private sanitizer: DomSanitizer
  ) {}

  useSample(): void {
    this.userMessage = this.samplePrompt;
  }

  generatePlan(): void {
    if (!this.userMessage.trim()) {
      this.errorMessage = 'Please enter your house requirements.';
      return;
    }

    this.loading = true;
    this.errorMessage = '';
    this.generated = false;
    this.safeSvg = null;
    this.selectedDesign = null;
    this.designOptions = [];

    const url = '/api/webhook-test/buildmind-generate';
    const body = { message: this.userMessage.trim() };

    this.http.post<any>(url, body).subscribe({
      next: (response) => {
        this.selectedDesign = response?.selectedDesign ?? null;
        this.designOptions = response?.designOptions ?? [];
        this.validation = response?.validation ?? null;
        this.rooms = response?.rooms ?? [];

        if (response?.svgPreview) {
          this.safeSvg = this.sanitizer.bypassSecurityTrustHtml(response.svgPreview);
        }

        this.generated = true;
        this.loading = false;
      },
      error: (error) => {
        console.error('BuildMind error:', error);
        this.errorMessage =
          'Unable to generate the plan. Make sure n8n is running and the webhook is listening.';
        this.loading = false;
      }
    });
  }

  resetDesign(): void {
    this.userMessage = '';
    this.safeSvg = null;
    this.selectedDesign = null;
    this.designOptions = [];
    this.validation = null;
    this.rooms = [];
    this.errorMessage = '';
    this.generated = false;
  }
}
