# BuildMind Frontend Sample

Angular sample frontend for the BuildMind n8n prototype.

## Requirements
- Node.js 24.x
- Angular CLI 21.x
- n8n running on http://localhost:5678
- n8n webhook test path: POST /webhook-test/buildmind-generate

## Run
```powershell
npm install
npm start
```
Then open http://localhost:4200

## n8n test mode
Before clicking **Generate 2D Plan**, open the Webhook node in n8n and click **Listen for test event**.

The Angular frontend sends:
```json
{ "message": "I have a 40 x 60 ft land..." }
```

The frontend expects the final n8n response to include fields such as:
- `selectedDesign`
- `designOptions`
- `validation`
- `rooms`
- `svgPreview`

## Production webhook later
When the n8n workflow is published/active, change this line in `src/app/app.ts`:
```ts
const url = '/api/webhook-test/buildmind-generate';
```
to:
```ts
const url = '/api/webhook/buildmind-generate';
```
