BuildMind Angular V2

Includes:
- Project requirement inputs
- Live 2D floor plan from x/y/width/height
- Auto Arrange 2D
- Existing n8n + Cloudflare render
- Customer AI chat UI

Run:
npm install
npx.cmd ng serve --open

Render webhook:
http://localhost:5678/webhook/buildmind-render

Chat webhook expected:
http://localhost:5678/webhook/buildmind-chat

Note: the chat UI is ready, but a separate n8n buildmind-chat workflow must be created/published for real AI replies.
