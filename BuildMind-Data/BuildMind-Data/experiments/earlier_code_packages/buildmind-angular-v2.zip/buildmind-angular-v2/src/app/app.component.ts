import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

interface Room { name:string; x:number; y:number; width:number; height:number; }
interface RenderResponse { success:boolean; message?:string; imageBase64?:string; imageDataUrl?:string; provider?:string; model?:string; }
interface ChatMessage { role:'user'|'assistant'; text:string; }

@Component({
  selector:'app-root', standalone:true, imports:[CommonModule,FormsModule],
  templateUrl:'./app.component.html', styleUrl:'./app.component.css'
})
export class AppComponent {
  renderWebhookUrl='http://localhost:5678/webhook/buildmind-render';
  chatWebhookUrl='http://localhost:5678/webhook/buildmind-chat';

  designName='Design A'; strategy='Front Public - Rear Private';
  landWidth=40; landLength=60; style='modern premium'; theme='day'; renderType='openRoof'; furnished=true;

  rooms:Room[]=[
    {name:'Living Room',x:0,y:0,width:30,height:14},
    {name:'Kitchen',x:0,y:14,width:14,height:11}
  ];

  loading=false; status:'Ready'|'Generating'|'Completed'|'Failed'='Ready';
  imageDataUrl=''; apiResponse='Waiting for request...';

  chatInput=''; chatLoading=false;
  messages:ChatMessage[]=[{role:'assistant',text:'Hi! I am BuildMind AI. Tell me your land size, rooms, budget, or preferred style.'}];

  constructor(private http:HttpClient, private cdr:ChangeDetectorRef){}

  addRoom(){ const i=this.rooms.length; this.rooms.push({name:`Room ${i+1}`,x:0,y:i*10,width:12,height:10}); }
  removeRoom(i:number){ this.rooms.splice(i,1); }

  autoArrangeRooms(){
    const maxW=Math.max(10,this.landWidth), gap=1; let x=0,y=0,rowH=0;
    this.rooms=this.rooms.map(r=>{
      const w=Math.max(6,Math.min(r.width||10,maxW)), h=Math.max(6,r.height||10);
      if(x+w>maxW){x=0;y+=rowH+gap;rowH=0;}
      const placed={...r,x,y,width:w,height:h}; x+=w+gap; rowH=Math.max(rowH,h); return placed;
    });
  }

  get planScale(){ return 520/Math.max(this.landWidth,this.landLength,1); }
  roomLeft(r:Room){ return r.x*this.planScale; }
  roomTop(r:Room){ return r.y*this.planScale; }
  roomWidthPx(r:Room){ return Math.max(30,r.width*this.planScale); }
  roomHeightPx(r:Room){ return Math.max(28,r.height*this.planScale); }

  buildPayload(){ return {
    selectedDesign:{name:this.designName,strategy:this.strategy,score:100},
    land:{width:this.landWidth,length:this.landLength,unit:'ft'},
    rooms:this.rooms,doors:[],windows:[],
    renderType:this.renderType,style:this.style,theme:this.theme,furnished:this.furnished
  };}

  async generateRender(){
    this.loading=true; this.status='Generating'; this.apiResponse='Sending request to n8n...'; this.cdr.detectChanges();
    try{
      const result=await firstValueFrom(this.http.post<RenderResponse|RenderResponse[]>(this.renderWebhookUrl,this.buildPayload()));
      const data=Array.isArray(result)?result[0]:result;
      this.apiResponse=JSON.stringify({success:data?.success,message:data?.message,provider:data?.provider,model:data?.model,imageBase64Length:data?.imageBase64?.length??0},null,2);
      if(!data?.success) throw new Error(data?.message||'Render failed');
      this.imageDataUrl=data.imageDataUrl || (data.imageBase64?`data:image/jpeg;base64,${data.imageBase64}`:'');
      if(!this.imageDataUrl) throw new Error('No image returned');
      this.status='Completed';
    }catch(e:any){this.status='Failed';this.apiResponse=`ERROR:\n${e?.message||e}`;}
    finally{this.loading=false;this.cdr.detectChanges();}
  }

  async sendChat(){
    const message=this.chatInput.trim(); if(!message||this.chatLoading)return;
    this.messages.push({role:'user',text:message}); this.chatInput=''; this.chatLoading=true; this.cdr.detectChanges();
    try{
      const result:any=await firstValueFrom(this.http.post(this.chatWebhookUrl,{message,project:'BuildMind',currentDesign:this.buildPayload()}));
      const data=Array.isArray(result)?result[0]:result;
      this.messages.push({role:'assistant',text:String(data?.reply||data?.message||data?.text||'No reply returned.')});
    }catch{
      this.messages.push({role:'assistant',text:'Chat UI is ready. Create and publish the n8n webhook "buildmind-chat" to connect a real AI chatbot.'});
    }finally{this.chatLoading=false;this.cdr.detectChanges();}
  }

  downloadImage(){ if(!this.imageDataUrl)return; const a=document.createElement('a');a.href=this.imageDataUrl;a.download=`buildmind-render-${Date.now()}.jpg`;a.click(); }
  get statusClass(){ return this.status.toLowerCase(); }
}
